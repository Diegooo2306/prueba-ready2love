# ATS — Sitio Web

Sitio institucional de **ATS Asesoría y Soluciones en Impuestos**. SPA (Single-Page Application) construida con React 18 + Babel standalone, sin herramienta de build.

---

## Estructura de archivos

```
ATS/
├── index.html          # Punto de entrada — meta tags SEO, OG, favicon, scripts
├── styles.css          # Todos los estilos (tema oscuro/claro, responsive)
├── app.jsx             # Componente raíz, router por estado, selector de tema
├── data.jsx            # Contenido editable: servicios, industrias, principios, estadísticas
├── shared.jsx          # Nav, Footer, useReveal (scroll reveal), selector de idioma
├── icons.jsx           # Iconos SVG
├── home.jsx            # Página de inicio
├── nosotros.jsx        # Página "Nosotros"
├── servicios.jsx       # Página de servicios + detalle de cada servicio
├── contacto.jsx        # Página de contacto (mailto + mapas embebidos)
├── privacidad.jsx      # Aviso de privacidad
├── tweaks-panel.jsx    # Panel de tweaks interno (tema oscuro/claro)
├── assets/
│   ├── logo.png              # Logo principal (580×140px)
│   ├── og-image.jpg          # Imagen para previews en redes sociales (1200×630px, 48 KB)
│   ├── favicon-32.png        # Favicon para pestañas del navegador (32×32px)
│   ├── favicon-192.png       # Favicon para Android / PWA (192×192px)
│   ├── apple-touch-icon.png  # Ícono para iOS (180×180px)
│   ├── imgclaro1.jpg         # Hero — variante clara 1 (1920px, 353 KB)
│   ├── imgclaro2.jpg         # Hero — variante clara 2 (1920px, 464 KB)
│   ├── imgobscuro1.jpg       # Hero — variante oscura 1 (1920px, 346 KB)
│   └── imgobscuro2.jpg       # Hero — variante oscura 2 (1920px, 456 KB)
├── uploads/
│   └── Retina-Logo.png       # Logo retina (alta resolución)
├── _redirects          # Reglas de redirección para Netlify / Cloudflare Pages
├── robots.txt          # Directivas para motores de búsqueda
└── sitemap.xml         # Mapa del sitio (7 URLs)
```

---

## Cómo correr localmente

El sitio no tiene servidor de build. Para verlo localmente necesitas un servidor HTTP (abrir el HTML directamente con `file://` bloquea los módulos `.jsx`).

**Opción 1 — Python (viene instalado en macOS/Linux):**
```bash
cd /ruta/al/proyecto/ATS
python3 -m http.server 8080
# Abrir http://localhost:8080
```

**Opción 2 — Node:**
```bash
npx serve .
```

**Opción 3 — VS Code:** instala la extensión *Live Server* y haz clic en "Go Live".

---

## Despliegue

El sitio es estático: un conjunto de archivos HTML/CSS/JS. Se puede subir directamente a:

| Plataforma | Instrucciones |
|---|---|
| **cPanel / Hosting tradicional** | Subir todos los archivos a `public_html` vía FTP o el administrador de archivos |
| **Cloudflare Pages** | Conectar el repo de Git; build command: vacío; output directory: `.` |
| **Netlify** | Arrastrar la carpeta al dashboard, o conectar Git. El archivo `_redirects` ya está configurado |
| **GitHub Pages** | Subir a un repo público, activar Pages desde `Settings > Pages` |

> **Nota sobre rutas:** El sitio usa navegación por estado de React (sin cambios de URL reales). Todos los visitantes llegan a `index.html`. El archivo `_redirects` redirige rutas directas (`/nosotros`, `/servicios`, etc.) de vuelta a `index.html` para que funcionen en Netlify / Cloudflare Pages.

---

## Cómo editar el contenido

### Textos y datos
Todo el contenido editable está centralizado en **`data.jsx`**:
- `SERVICES` — Los 6 servicios: título, descripción corta, descripción larga, puntos clave
- `ENFOQUE` — Los 5 principios de la firma
- `INDUSTRIES` — Las industrias del marquee
- `STATS` — Los 4 números de la sección "En números"

### Textos de página
Los textos del hero, manifiesto, CTAs, etc. están directamente en cada archivo `.jsx` de página.

### Colores / tema
Las variables CSS están al inicio de `styles.css`:
- `--gold` / `--gold-bright` / `--gold-deep` — Acento principal (rojo Pantone 185 C)
- `--gold-warm` — Acento secundario (naranja Pantone 1375 C)
- `--brand-blue` — Azul de marca (Pantone 534 C)
- `--accent-grad` — Gradiente de acento (rojo → naranja)
- El bloque `[data-theme="light"]` define el tema claro

---

## Selector de idioma (ES / EN)

El toggle ES/EN en el nav usa **Google Translate** mediante cookies. Al seleccionar EN se escribe el cookie `googtrans=/es/en` y se recarga la página; Google Translate aplica la traducción automáticamente. Al regresar a ES se borra el cookie y se recarga. El estado del botón se lee del cookie al iniciar, por lo que se mantiene resaltado correctamente tras la recarga.

---

## Contacto

El botón "Enviar mensaje" en la página de Contacto abre el cliente de correo del visitante con un `mailto:contacto@atsconsulting.mx` (diseño intencional; no hay backend de formulario).

Los teléfonos y correos en ambas sedes (CDMX y Bajío) son enlaces clickeables (`tel:` y `mailto:`).

---

## Dependencias (CDN — sin instalación)

| Librería | Versión | Propósito |
|---|---|---|
| React | 18.3.1 | UI reactiva |
| ReactDOM | 18.3.1 | Renderizado |
| Babel Standalone | 7.29.0 | Transpilación JSX en browser |
| Google Fonts | — | Instrument Serif, Manrope, JetBrains Mono |
| Google Translate | — | Traducción ES/EN vía cookie `googtrans` |

---

## SEO y redes sociales

- **Canonical:** `https://atsconsulting.mx/`
- **OG image:** `https://atsconsulting.mx/assets/og-image.jpg` (1200×630px)
- **Sitemap:** `https://atsconsulting.mx/sitemap.xml`
- **robots.txt:** permite todo excepto `/uploads/`

---

## Contacto del proyecto

**Cliente:** ATS Asesoría y Soluciones en Impuestos
**Desarrollo:** Mantic Consulting — licenciamiento@mantic-consulting.com
