/* global React, ReactDOM, window */
const { useState: useStateApp, useEffect: useEffectApp } = React;

/* ── URL ↔ Estado (hash routing) ─────────────────────────────── */
function getStateFromHash() {
  const hash = window.location.hash.replace(/^#\/?/, '');
  if (!hash || hash === '')                        return { page: 'home',       service: null };
  if (hash === 'nosotros')                         return { page: 'nosotros',   service: null };
  if (hash === 'servicios')                        return { page: 'servicios',  service: null };
  if (hash.startsWith('servicios/'))               return { page: 'servicios',  service: hash.slice('servicios/'.length) };
  if (hash === 'contacto')                         return { page: 'contacto',   service: null };
  if (hash === 'privacidad')                       return { page: 'privacidad', service: null };
  return { page: 'home', service: null };
}

function buildHash(page, service) {
  if (page === 'home')                       return '#';
  if (page === 'servicios' && service)       return `#servicios/${service}`;
  return `#${page}`;
}

/* ── App ──────────────────────────────────────────────────────── */
function App() {
  const initial = getStateFromHash();
  const [page, setPage] = useStateApp(initial.page);
  const [selectedService, setSelectedService] = useStateApp(initial.service);
  const [theme, setTheme] = useStateApp('light');

  useEffectApp(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  // Sincroniza URL → estado al usar los botones Atrás / Adelante del navegador
  useEffectApp(() => {
    const onHashChange = () => {
      const s = getStateFromHash();
      setPage(s.page);
      setSelectedService(s.service);
      window.scrollTo({ top: 0, behavior: 'instant' });
    };
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  const toggleTheme = () => setTheme((t) => (t === 'light' ? 'dark' : 'light'));

  const navigate = (p, service = null) => {
    const hash = buildHash(p, service);
    window.location.hash = hash;
    setPage(p);
    setSelectedService(service);
    window.scrollTo({ top: 0, behavior: 'instant' });
  };

  const setPageAndReset = (p) => navigate(p, null);

  const openService = (id) => navigate('servicios', id);

  const setSelected = (id) => {
    if (id) {
      navigate('servicios', id);
    } else {
      navigate('servicios', null);
    }
  };

  return (
    <div className="app">
      <div className="bg-grid" />
      <window.Nav page={page} setPage={setPageAndReset} theme={theme} toggleTheme={toggleTheme} />

      {page === 'home'       && <window.HomePage      setPage={setPageAndReset} openService={openService} theme={theme} />}
      {page === 'nosotros'   && <window.NosotrosPage   setPage={setPageAndReset} />}
      {page === 'servicios'  && <window.ServiciosPage  setPage={setPageAndReset} selected={selectedService} setSelected={setSelected} />}
      {page === 'contacto'   && <window.ContactoPage />}
      {page === 'privacidad' && <window.PrivacidadPage setPage={setPageAndReset} />}

      <window.Footer setPage={setPageAndReset} />
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
