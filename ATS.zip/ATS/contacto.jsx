/* global React, window */
const { Icon: IconC, useReveal: useRevealC } = window;

function ContactoPage() {
  useRevealC();

  return (
    <div className="page-enter">
      <section className="svc-hero">
        <div className="container">
          <div className="eyebrow reveal" style={{ marginBottom: 40 }}>/ Contacto</div>
          <h1 className="about-hero-title reveal serif">
            Hablemos de<br /><em>tu operación.</em>
          </h1>
          <p className="section-lead reveal d1" style={{ marginTop: 32, maxWidth: '60ch' }}>
            Cuéntanos brevemente sobre tu empresa y el reto fiscal que estás enfrentando. Respondemos en menos de 24 horas hábiles.
          </p>
          <p className="section-lead reveal d2" style={{ marginTop: 24, maxWidth: '60ch', fontSize: 17 }}>
            Para Asesoría y Soluciones en Impuestos, nuestros clientes son la parte elemental de nuestro trabajo. Por ello buscamos proporcionar apoyo en los dilemas en contabilidad que puedan presentar en su actuar diario, brindándoles nuestros servicios los 365 días del año.
          </p>
          <div className="reveal d2" style={{ marginTop: 48 }}>
            <a
              href="mailto:contacto@atsconsulting.mx"
              className="btn btn-primary"
              style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}
            >
              Enviar mensaje <span className="btn-arrow">→</span>
            </a>
          </div>
        </div>
      </section>

      <section className="section" style={{ paddingTop: 60 }}>
        <div className="container">
          <div className="eyebrow reveal" style={{ marginBottom: 40 }}>/ Visítanos</div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 32 }}>

            {/* CDMX */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.4fr', gap: 32, alignItems: 'stretch' }} className="reveal">
              <div className="location" style={{ margin: 0 }}>
                <div className="location-tag">Sede principal</div>
                <h3 className="serif">Ciudad de México</h3>
                <p style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
                  <IconC name="pin" size={16} />
                  <a href="https://www.google.com/maps?q=C.+Orizaba+9,+Roma+Nte.,+Cuauhtémoc,+06700+Ciudad+de+México,+CDMX" target="_blank" rel="noreferrer" style={{ color: 'inherit', textDecoration: 'underline', textUnderlineOffset: 3 }}>
                    C. Orizaba 9<br />Col. Roma Norte, Cuauhtémoc, 06700
                  </a>
                </p>
                <p style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <IconC name="phone" size={16} /><a href="tel:+525526107714" style={{ color: 'inherit' }}>+52 55 2610 7714</a>
                </p>
                <p style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <IconC name="mail" size={16} /><a href="mailto:contacto@atsconsulting.mx" style={{ color: 'inherit' }}>contacto@atsconsulting.mx</a>
                </p>
              </div>
              <div style={{ position: 'relative', border: '1px solid var(--line)', overflow: 'hidden', minHeight: 220 }}>
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3762.744853938726!2d-99.16371594905496!3d19.423427054306448!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d1ff3126a275c1%3A0x707b0c98604fafb6!2sC.%20Orizaba%209%2C%20Roma%20Nte.%2C%20Cuauht%C3%A9moc%2C%2006700%20Ciudad%20de%20M%C3%A9xico%2C%20CDMX!5e0!3m2!1ses-419!2smx!4v1779913487427!5m2!1ses-419!2smx"
                  width="100%" height="100%"
                  style={{ border: 0, display: 'block', minHeight: 220 }}
                  allowFullScreen="" loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="CDMX"
                />
                <span className="about-img-cap">CDMX · Sede Principal</span>
              </div>
            </div>

            {/* Bajío */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.4fr', gap: 32, alignItems: 'stretch' }} className="reveal d1">
              <div className="location" style={{ margin: 0 }}>
                <div className="location-tag">Oficina regional</div>
                <h3 className="serif">Bajío</h3>
                <p style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
                  <IconC name="pin" size={16} />
                  <a href="https://www.google.com/maps?q=20.573606,-100.361458" target="_blank" rel="noreferrer" style={{ color: 'inherit', textDecoration: 'underline', textUnderlineOffset: 3 }}>
                    Blvd. Adolfo López Mateos 2475<br />Col. Las Reynas, León, Gto. 37549
                  </a>
                </p>
                <p style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <IconC name="phone" size={16} /><a href="tel:+525526107714" style={{ color: 'inherit' }}>+52 55 2610 7714</a>
                </p>
                <p style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <IconC name="mail" size={16} /><a href="mailto:contacto@atsconsulting.mx" style={{ color: 'inherit' }}>contacto@atsconsulting.mx</a>
                </p>
              </div>
              <div style={{ position: 'relative', border: '1px solid var(--line)', overflow: 'hidden', minHeight: 220 }}>
                <iframe
                  src="https://maps.google.com/maps?q=20.573606,-100.361458&z=15&output=embed"
                  width="100%" height="100%"
                  style={{ border: 0, display: 'block', minHeight: 220 }}
                  allowFullScreen="" loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Bajío"
                />
                <span className="about-img-cap">Bajío · Oficina Regional</span>
              </div>
            </div>

            <div style={{ padding: '24px 0', borderTop: '1px solid var(--line)', display: 'flex', flexDirection: 'column', gap: 8 }} className="reveal d2">
              <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, letterSpacing: '0.18em', color: 'var(--gold)', textTransform: 'uppercase' }}>Horario</span>
              <p style={{ color: 'var(--fg)', fontSize: 15 }}>Lunes a viernes · 9:00 – 18:00 hrs</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

window.ContactoPage = ContactoPage;
