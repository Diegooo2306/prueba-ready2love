/* global React, window */
const { useState: useStateH, useEffect: useEffectH } = React;
const { Icon: IconH, useReveal: useRevealH } = window;
const { SERVICES: SERVICES_H, ENFOQUE: ENFOQUE_H, INDUSTRIES: INDUSTRIES_H, STATS: STATS_H } = window.ATS_DATA;

function Hero({ setPage, theme }) {
  const [slide, setSlide] = useStateH(0);

  const slidesByTheme = {
    light: [
      {
        img: 'assets/imgclaro1.jpg',
        eyebrow: '/ Firma fiscal · México',
        title: ['Asesorías', 'en', 'impuestos.'],
        italicIndex: 2,
        sub: 'Somos profesionales con más de 20 años enfocados en la asesoría de operaciones nacionales e internacionales.',
      },
      {
        img: 'assets/imgclaro2.jpg',
        eyebrow: '/ Estrategia · Cumplimiento',
        title: ['Soluciones', 'en', 'un', 'ambiente', 'de', 'oportunidades.'],
        italicIndex: 5,
        sub: 'Comprendemos el negocio de nuestros clientes y creamos soluciones acorde con sus intereses.',
      },
    ],
    dark: [
      {
        img: 'assets/imgobscuro1.jpg',
        eyebrow: '/ Firma fiscal · México',
        title: ['Asesorías', 'en', 'impuestos.'],
        italicIndex: 2,
        sub: 'Somos profesionales con más de 20 años enfocados en la asesoría de operaciones nacionales e internacionales.',
      },
      {
        img: 'assets/imgobscuro2.jpg',
        eyebrow: '/ Estrategia · Cumplimiento',
        title: ['Soluciones', 'en', 'un', 'ambiente', 'de', 'oportunidades.'],
        italicIndex: 5,
        sub: 'Comprendemos el negocio de nuestros clientes y creamos soluciones acorde con sus intereses.',
      },
    ],
  };

  const slides = slidesByTheme[theme] || slidesByTheme.light;

  useEffectH(() => {
    const t = setInterval(() => setSlide((s) => (s + 1) % slides.length), 8000);
    return () => clearInterval(t);
  }, []);

  const current = slides[slide];

  return (
    <section className="hero" key={slide}>
      <div className="hero-bg">
        <img src={current.img} alt="CDMX" />
      </div>
      <div className="hero-overlay" />

      <div className="hero-content">
        <div className="hero-eyebrow eyebrow">{current.eyebrow}</div>
        <h1 className="hero-title">
          {current.title.map((w, i) => (
            <React.Fragment key={i}>
              <span
                className={`word ${i === current.italicIndex ? 'italic serif' : ''}`}
                style={{ animationDelay: `${0.4 + i * 0.12}s` }}
              >
                {w}
              </span>
              {i < current.title.length - 1 ? ' ' : null}
            </React.Fragment>
          ))}
        </h1>
        <p className="hero-sub">{current.sub}</p>
        <div className="hero-cta-row">
          <button className="btn btn-primary" onClick={() => setPage('contacto')}>
            Contáctanos <span className="btn-arrow">→</span>
          </button>
          <button className="btn btn-ghost" onClick={() => setPage('nosotros')}>
            Conócenos
          </button>
        </div>
      </div>

      <div className="hero-meta">
        <span><span className="num">0{slide + 1}</span> / 0{slides.length}</span>
        <span>CDMX · 19.4°N</span>
        <div style={{ display: 'flex', gap: 6, justifyContent: 'flex-end', marginTop: 8 }}>
          {slides.map((_, i) => (
            <button
              key={i}
              onClick={() => setSlide(i)}
              style={{
                width: i === slide ? 28 : 16,
                height: 2,
                background: i === slide ? 'var(--gold)' : 'var(--fg-mute)',
                transition: 'all 0.4s',
                cursor: 'pointer',
              }}
            />
          ))}
        </div>
      </div>

      <div className="hero-scroll">
        <span>Scroll</span>
        <div className="hero-scroll-line" />
      </div>
    </section>
  );
}

function Intro({ setPage }) {
  return (
    <section className="section">
      <div className="container">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.4fr', gap: 80, alignItems: 'center' }} className="intro-grid">
          <div className="reveal">
            <div className="eyebrow" style={{ marginBottom: 24 }}>/ La firma</div>
            <h2 className="section-title">
              <em className="serif">ATS</em>
            </h2>
          </div>
          <div className="reveal d1">
            <p style={{ fontSize: 20, color: 'var(--fg)', lineHeight: 1.5, marginBottom: 24 }}>
              Una firma que proporciona soluciones de negocios con <em style={{ color: 'var(--gold)', fontFamily: 'Instrument Serif, serif' }}>experiencia, respuesta inmediata e integridad</em> en el ámbito fiscal.
            </p>
            <p style={{ fontSize: 16, color: 'var(--fg-dim)', marginBottom: 32 }}>
              Trabajamos con empresas que buscan claridad regulatoria y soluciones tributarias robustas, sostenidas por un equipo con sólida experiencia en industrias clave del país.
            </p>
            <button className="btn btn-ghost" onClick={() => setPage('nosotros')}>
              Saber más <span className="btn-arrow">→</span>
            </button>
          </div>
        </div>
      </div>
      <style>{`@media (max-width: 880px) { .intro-grid { grid-template-columns: 1fr !important; gap: 32px !important; } }`}</style>
    </section>
  );
}

function Enfoque({ setPage }) {
  const [active, setActive] = useStateH(0);
  return (
    <section className="section" style={{ borderTop: '1px solid var(--line)' }}>
      <div className="container">
        <div className="section-header">
          <div className="reveal">
            <div className="eyebrow" style={{ marginBottom: 24 }}>/ Nuestro enfoque</div>
            <h2 className="section-title">Cinco<br /><em>principios.</em></h2>
          </div>
          <p className="section-lead reveal d1">
            La metodología que sostiene cada compromiso. No son valores en una pared — son la manera en que decidimos, comunicamos y entregamos.
          </p>
        </div>

        <div className="enfoque reveal d2">
          <div className="enfoque-tabs">
            {ENFOQUE_H.map((e, i) => (
              <button
                key={i}
                className={`enfoque-tab ${active === i ? 'active' : ''}`}
                onClick={() => setActive(i)}
              >
                <span className="num">{e.num}</span>
                {e.title}
              </button>
            ))}
          </div>
          <div className="enfoque-panel" key={active}>
            <div className="page-enter">
              <div className="enfoque-panel-num">{ENFOQUE_H[active].num} / 05</div>
              <div className="enfoque-panel-title">{ENFOQUE_H[active].title}</div>
              <p className="enfoque-panel-text">{ENFOQUE_H[active].text}</p>
            </div>
            <div className="enfoque-panel-actions">
              <button className="btn btn-primary" onClick={() => setPage('nosotros')}>Saber más <span className="btn-arrow">→</span></button>
              <button className="btn btn-ghost" onClick={() => setPage('contacto')}>Contáctanos</button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function ServicesBento({ setPage, openService }) {
  const iconMap = ['corporate', 'legal', 'compliance', 'local', 'trade', 'human', 'cyber'];
  const layout = ['wide', 'wide', 'narrow', 'narrow', 'narrow', 'narrow', 'wide'];

  const onCardMove = (e) => {
    const card = e.currentTarget;
    const r = card.getBoundingClientRect();
    card.style.setProperty('--mx', `${e.clientX - r.left}px`);
    card.style.setProperty('--my', `${e.clientY - r.top}px`);
  };

  return (
    <section className="section" style={{ borderTop: '1px solid var(--line)' }}>
      <div className="container">
        <div className="section-header">
          <div className="reveal">
            <div className="eyebrow" style={{ marginBottom: 24 }}>/ Nuestros servicios</div>
            <h2 className="section-title">Siete prácticas,<br /><em>una sola visión.</em></h2>
          </div>
          <p className="section-lead reveal d1">
            Asesoría fiscal integral, desde estrategia corporativa hasta cumplimiento operativo, articulada por especialistas que entienden cada industria.
          </p>
        </div>

        <div className="services-grid">
          {SERVICES_H.map((s, i) => (
            <div
              key={s.id}
              className={`service-card ${layout[i] || ''} reveal d${(i % 4) + 1}`}
              onMouseMove={onCardMove}
              onClick={() => openService(s.id)}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <span className="service-card-num">{s.num} — Servicio</span>
                <span className="service-card-icon"><IconH name={iconMap[i]} size={40} /></span>
              </div>
              <div>
                <h3 className="service-card-title">{s.title}</h3>
                <p style={{ fontSize: 14.5, color: 'var(--fg-dim)' }}>{s.short}</p>
                <div className="service-card-text">{s.desc}</div>
                <div className="service-card-arrow">
                  Ver detalle
                  <IconH name="arrow" size={16} />
                </div>
              </div>
            </div>
          ))}
        </div>

        <div style={{ textAlign: 'center', marginTop: 64 }} className="reveal">
          <button className="btn btn-ghost" onClick={() => setPage('servicios')}>
            Conoce más <span className="btn-arrow">→</span>
          </button>
        </div>
      </div>
    </section>
  );
}

function IndustriesMarquee() {
  const items = [...INDUSTRIES_H, ...INDUSTRIES_H, ...INDUSTRIES_H, ...INDUSTRIES_H];
  return (
    <section className="industries">
      <div className="marquee">
        {items.map((it, i) => (
          <div className="marquee-item" key={i}>
            <span className="marquee-dot" />
            {i % 3 === 1 ? <em>{it}</em> : it}
          </div>
        ))}
      </div>
    </section>
  );
}

function CountUp({ end }) {
  const [n, setN] = useStateH(0);
  const ref = React.useRef(null);
  useEffectH(() => {
    let raf;
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) {
          const start = performance.now();
          const dur = 1400;
          const animate = (t) => {
            const p = Math.min(1, (t - start) / dur);
            const eased = 1 - Math.pow(1 - p, 3);
            setN(Math.round(end * eased));
            if (p < 1) raf = requestAnimationFrame(animate);
          };
          raf = requestAnimationFrame(animate);
          io.disconnect();
        }
      });
    }, { threshold: 0.5 });
    if (ref.current) io.observe(ref.current);
    return () => { if (raf) cancelAnimationFrame(raf); io.disconnect(); };
  }, [end]);
  return <span ref={ref}>{n}</span>;
}

function StatsBlock() {
  return (
    <section className="section">
      <div className="container">
        <div className="section-header">
          <div className="reveal">
            <div className="eyebrow" style={{ marginBottom: 24 }}>/ En números</div>
            <h2 className="section-title">Una trayectoria<br /><em>medible.</em></h2>
          </div>
          <p className="section-lead reveal d1">
            20 años de práctica continua en operaciones nacionales e internacionales — una huella construida proyecto por proyecto.
          </p>
        </div>

        <div className="stats">
          {STATS_H.map((s, i) => (
            <div className="stat reveal" style={{ transitionDelay: `${i * 0.08}s` }} key={i}>
              <div className="stat-num">
                <CountUp end={parseInt(s.num, 10)} />
                {s.suffix ? <span className="plus">{s.suffix}</span> : null}
              </div>
              <div className="stat-label">{s.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function CTASection({ setPage }) {
  return (
    <section className="cta-section">
      <div className="container">
        <h2 className="cta-title reveal">
          Comprendemos<br /><em>tu negocio.</em>
        </h2>
        <p className="cta-text reveal d1">
          Conversemos sobre cómo podemos articular soluciones fiscales acordes a tus intereses.
        </p>
        <div className="cta-buttons reveal d2">
          <button className="btn btn-primary" onClick={() => setPage('contacto')}>
            Contáctanos <span className="btn-arrow">→</span>
          </button>
          <button className="btn btn-ghost" onClick={() => setPage('servicios')}>
            Ver servicios
          </button>
        </div>
      </div>
    </section>
  );
}

function HomePage({ setPage, openService, theme }) {
  useRevealH();
  return (
    <div className="page-enter">
      <Hero setPage={setPage} theme={theme} />
      <Intro setPage={setPage} />
      <IndustriesMarquee />
      <Enfoque setPage={setPage} />
      <ServicesBento setPage={setPage} openService={openService} />
      <StatsBlock />
      <CTASection setPage={setPage} />
    </div>
  );
}

window.HomePage = HomePage;
