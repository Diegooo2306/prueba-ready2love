/* global React, window */
const { useReveal: useRevealP } = window;

function PrivacidadPage({ setPage }) {
  useRevealP();

  return (
    <div className="page-enter">

      {/* Hero */}
      <section className="svc-hero">
        <div className="container">
          <div className="eyebrow reveal" style={{ marginBottom: 40 }}>/ Legal · Privacidad</div>
          <h1 className="about-hero-title reveal serif">
            Aviso de<br /><em>Privacidad.</em>
          </h1>
          <p className="section-lead reveal d1" style={{ marginTop: 24 }}>
            A&amp;TS Integrated Tax Services, S.C. · Última actualización: 27 de mayo de 2026
          </p>
        </div>
      </section>

      {/* Contenido legal */}
      <section className="section" style={{ paddingTop: 0 }}>
        <div className="container">
          <div className="legal-layout">

            {/* Índice lateral */}
            <nav className="legal-index reveal">
              <div className="eyebrow" style={{ marginBottom: 24 }}>/ Contenido</div>
              <ol className="legal-toc">
                {['responsable','datos','fines','transferencia','arco','modificaciones'].map((id, i) => {
                  const labels = ['Responsable','Datos que recabamos','Finalidades','Transferencia','Derechos ARCO','Modificaciones'];
                  return (
                    <li key={id}>
                      <a href={`#${id}`} onClick={(e) => {
                        e.preventDefault();
                        document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
                      }}>{labels[i]}</a>
                    </li>
                  );
                })}
              </ol>
            </nav>

            {/* Cuerpo */}
            <div className="legal-body reveal d1">

              {/* Introducción */}
              <div className="legal-intro">
                <p>
                  En cumplimiento a la <strong>Ley Federal de Protección de Datos Personales en Posesión de Particulares</strong> (la "Ley"), se emite el presente Aviso de Privacidad en los siguientes términos:
                </p>
              </div>

              {/* 1. Responsable */}
              <div className="legal-section" id="responsable">
                <div className="legal-section-label">01</div>
                <h2 className="legal-section-title">Responsable de los Datos Personales</h2>
                <p className="legal-text">
                  <strong>A&amp;TS Integrated Tax Services, S.C.</strong> (en adelante "ATS"), con domicilio en calle Shakespeare no. 84, piso 5, colonia Anzures, alcaldía Miguel Hidalgo, C.P. 11590, Ciudad de México, pone a su disposición el presente Aviso de Privacidad, con la finalidad de que conozca de qué manera se usan, divulgan y almacenan sus datos personales ("Titular"), a efecto de garantizar la privacidad de dicha información y el derecho a la autodeterminación informativa de las personas.
                </p>
              </div>

              {/* 2. Datos */}
              <div className="legal-section" id="datos">
                <div className="legal-section-label">02</div>
                <h2 className="legal-section-title">¿Qué datos personales se solicitan?</h2>
                <p className="legal-text">
                  Para llevar a cabo las finalidades descritas en el presente Aviso de Privacidad, ATS podrá recabar los siguientes datos personales del Titular ("Datos Personales"):
                </p>
                <ul className="legal-list">
                  <li>Nombre completo</li>
                  <li>Registro Federal de Contribuyentes</li>
                  <li>Clave Única de Registro de Población</li>
                  <li>Domicilio</li>
                  <li>Teléfono celular</li>
                  <li>Correo electrónico</li>
                  <li>Datos Migratorios</li>
                  <li>Información Patrimonial (relación de bienes muebles y/o inmuebles)</li>
                  <li>Información financiera (información fiscal y/o cuentas bancarias)</li>
                </ul>
                <p className="legal-text">
                  Es responsabilidad del Titular de los Datos Personales garantizar que los datos que facilite personal o directamente a ATS sean veraces y completos, así como notificar a ATS cualquier modificación a los mismos para dar cumplimiento a la obligación de mantener la información actualizada.
                </p>
              </div>

              {/* 3. Fines */}
              <div className="legal-section" id="fines">
                <div className="legal-section-label">03</div>
                <h2 className="legal-section-title">¿Para qué fines utilizaremos sus datos personales?</h2>
                <p className="legal-text">
                  Los Datos Personales que ATS recabará del Titular serán utilizados para las siguientes <strong>finalidades primarias</strong>, necesarias para prestar los Servicios:
                </p>
                <ul className="legal-list legal-list--roman">
                  <li>Para la prestación de los servicios por parte de ATS ("Servicios").</li>
                  <li>Para el cumplimiento de los contratos que ATS celebre con el Titular.</li>
                  <li>Para la administración de los Servicios.</li>
                  <li>Para contactar al Titular para dar cumplimiento a los Servicios.</li>
                </ul>
                <p className="legal-text" style={{ marginTop: 24 }}>
                  De manera adicional, ATS utilizará su información personal para las siguientes <strong>finalidades secundarias</strong> que no son necesarias para prestar los Servicios, pero que permiten y facilitan a ATS brindarle una mejor atención:
                </p>
                <ul className="legal-list legal-list--roman">
                  <li>Prospección comercial.</li>
                  <li>Envío de invitaciones, boletines e información de los Servicios.</li>
                  <li>Evaluar la calidad de los Servicios.</li>
                </ul>
                <p className="legal-text legal-note" style={{ marginTop: 24 }}>
                  En caso de que no desee que sus Datos Personales se utilicen para estos fines secundarios, puede negarnos su consentimiento conforme a los lineamientos establecidos en el punto "Derechos ARCO". La negativa para el uso de sus Datos Personales para estas finalidades secundarias no podrá ser motivo para negarle la prestación de los Servicios.
                </p>
              </div>

              {/* 4. Transferencia */}
              <div className="legal-section" id="transferencia">
                <div className="legal-section-label">04</div>
                <h2 className="legal-section-title">Transferencia de información</h2>
                <p className="legal-text">
                  De acuerdo con lo dispuesto por la Ley, ATS podrá dar acceso a los Datos Personales del Titular (a través de remisiones), a aquellas personas que tengan el carácter de Encargados, como pueden ser prestadores de servicios o socios de ATS, que tengan una relación jurídica con este último y que derivado de dicha relación jurídica necesiten conocer dicha información y quienes en todo momento deberán dar cumplimiento a los términos y condiciones del presente Aviso de Privacidad.
                </p>
                <p className="legal-text">
                  En caso de que los Datos Personales resguardados sean requeridos por una autoridad de cualquier índole o deban ser entregados a ésta de acuerdo con la legislación vigente, estos datos se pondrán a su disposición dentro del estricto cumplimiento a la Ley, transferencia que no requiere del consentimiento del Titular de acuerdo con lo dispuesto en el artículo 37 de la Ley.
                </p>
              </div>

              {/* 5. ARCO */}
              <div className="legal-section" id="arco">
                <div className="legal-section-label">05</div>
                <h2 className="legal-section-title">Derechos ARCO (Acceso, Rectificación, Cancelación y Oposición)</h2>
                <p className="legal-text">El Titular tiene los siguientes derechos con respecto a sus Datos Personales:</p>

                <div className="legal-right">
                  <div className="legal-right-title">Acceso y Rectificación</div>
                  <p className="legal-text">Usted podrá solicitar que ATS le haga saber los Datos Personales que conserva en sus bases de datos, y puede requerir que en caso de existir algún error en ellos se rectifiquen.</p>
                </div>
                <div className="legal-right">
                  <div className="legal-right-title">Cancelación</div>
                  <p className="legal-text">Usted puede solicitar que se cancelen los Datos Personales, lo puede hacer personalmente o por conducto de su representante legal, debidamente acreditado. Existen casos en que los Datos Personales no pueden ser cancelados por disposición de Ley.</p>
                </div>
                <div className="legal-right">
                  <div className="legal-right-title">Oposición</div>
                  <p className="legal-text">Usted puede oponerse al tratamiento que se les da a los Datos Personales, lo puede hacer personalmente o por conducto de su representante legal.</p>
                </div>

                <p className="legal-text" style={{ marginTop: 24 }}>Lo anterior lo podrá llevar a cabo mediante:</p>
                <ul className="legal-list legal-list--roman">
                  <li>Solicitud enviada a través del correo electrónico <strong>contacto@atsconsulting.mx</strong>.</li>
                  <li>Solicitud por escrito dirigida a <strong>Enrique Augusto Zamora Paredes</strong>, enviada al domicilio Shakespeare no. 84, piso 5, colonia Anzures, Alcaldía Miguel Hidalgo, C.P. 11590, Ciudad de México, de lunes a viernes en un horario de 9:00 a 17:00 horas.</li>
                </ul>

                <p className="legal-text" style={{ marginTop: 24 }}>Para que ATS dé trámite a la solicitud, el Titular deberá adjuntar:</p>
                <ul className="legal-list legal-list--roman">
                  <li>Nombre del Titular y domicilio u otro medio para comunicarle la respuesta.</li>
                  <li>Los documentos con los que acredite su identidad o su personalidad en caso de representación legal (identificación oficial y, en su caso, poder notarial).</li>
                  <li>Descripción clara y precisa de los Datos Personales respecto de los que se busca ejercer los derechos ARCO, así como cualquier dato que facilite su localización.</li>
                </ul>

                <p className="legal-text legal-note" style={{ marginTop: 24 }}>
                  De conformidad con el artículo 32 de la Ley, ATS atenderá su solicitud en un plazo máximo de <strong>20 días hábiles</strong> contados a partir de la fecha de recepción de su solicitud de acceso, rectificación, cancelación u oposición. Se le dará contestación por medio de correo electrónico dirigido a su persona, enviado a la dirección de correo electrónico que haya indicado en la propia solicitud o enviando carta al domicilio físico que haya indicado. Dentro de dicho plazo le informaremos sobre la procedencia de la misma y en caso de ser aplicable, se hará efectiva la misma dentro de los <strong>15 días siguientes</strong> a la fecha en que se comunique la respuesta. Se considerará que ATS cumplió en el momento en la fecha en que responda a su correo electrónico o se reciba el acuse de recibido y lectura en su caso, o se entregue al correo postal.
                </p>
                <p className="legal-text legal-note">
                  En caso de revocación del consentimiento, tenga en cuenta que no en todos los casos ATS podrá atender su solicitud de forma inmediata, ya que por alguna obligación legal podría requerirse seguir tratando sus Datos Personales. Asimismo, para ciertos fines, la revocación de su consentimiento implicará que no podamos seguir prestándole los Servicios solicitados.
                </p>
              </div>

              {/* 6. Modificaciones */}
              <div className="legal-section" id="modificaciones">
                <div className="legal-section-label">06</div>
                <h2 className="legal-section-title">Modificaciones al Aviso de Privacidad</h2>
                <p className="legal-text">
                  Las modificaciones que puedan hacerse al presente aviso se podrán verificar en la página <strong>https://atsconsulting.mx/aviso-de-privacidad/</strong>.
                </p>
                <p className="legal-text">
                  El presente Aviso de Privacidad se rige por la legislación vigente y aplicable en los Estados Unidos Mexicanos. Cualquier controversia que se suscite con motivo de su aplicación deberá ventilarse ante el <strong>Instituto Nacional de Transparencia, Acceso a la Información y Protección de Datos Personales (INAI)</strong> o ante los órganos jurisdiccionales competentes en la Ciudad de México.
                </p>
              </div>

              {/* Back */}
              <div style={{ marginTop: 64, paddingTop: 32, borderTop: '1px solid var(--line)' }}>
                <button className="btn btn-ghost" onClick={() => setPage('home')}>
                  ← Volver al inicio
                </button>
              </div>

            </div>
          </div>
        </div>
      </section>

    </div>
  );
}

window.PrivacidadPage = PrivacidadPage;
