/* global React, window */
const { useState, useEffect, useRef } = React;
const { Icon } = window;

// ----- useReveal: IntersectionObserver-based scroll reveal -----
function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll('.reveal:not(.in)');
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add('in');
            io.unobserve(e.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -80px 0px' }
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  });
}

// ----- Nav -----
function Nav({ page, setPage, theme, toggleTheme }) {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [lang, setLang] = useState(() =>
    document.cookie.includes('googtrans=/es/en') ? 'EN' : 'ES'
  );

  const handleLang = (newLang) => {
    if (newLang === lang) return;
    const exp = new Date(0).toUTCString();
    if (newLang === 'EN') {
      document.cookie = 'googtrans=/es/en; path=/';
      document.cookie = 'googtrans=/es/en; path=/; domain=.' + location.hostname;
    } else {
      document.cookie = 'googtrans=; path=/; expires=' + exp;
      document.cookie = 'googtrans=; path=/; domain=.' + location.hostname + '; expires=' + exp;
    }
    window.location.reload();
  };

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [page]);

  const items = [
    { id: 'home', label: 'Inicio' },
    { id: 'nosotros', label: 'Nosotros' },
    { id: 'servicios', label: 'Servicios' },
    { id: 'contacto', label: 'Contacto' },
  ];

  return (
    <React.Fragment>
      <nav className={`nav ${scrolled ? 'scrolled' : ''}`}>
        <div className="brand" onClick={() => setPage('home')}>
          <div className="brand-mark" aria-label="ATS logo">
            <svg viewBox="0 0 36 32" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <linearGradient id="ats-dot-2" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0" stopColor="#E30513"/>
                  <stop offset="1" stopColor="#FF9E15"/>
                </linearGradient>
              </defs>
              <circle cx="10" cy="16" r="7" fill="#E30513"/>
              <circle cx="27" cy="8"  r="7" fill="url(#ats-dot-2)"/>
              <circle cx="27" cy="24" r="7" fill="#FF9E15"/>
            </svg>
          </div>
          <div className="brand-text">
            <span className="brand-name">ATS</span>
            <span className="brand-sub">Asesoría y Soluciones</span>
          </div>
        </div>

        <div className="nav-links">
          {items.map((it) => (
            <button
              key={it.id}
              className={`nav-link ${page === it.id ? 'active' : ''}`}
              onClick={() => setPage(it.id)}
            >
              {it.label}
            </button>
          ))}
          <button className="nav-cta" onClick={() => setPage('contacto')}>
            Contáctanos <Icon name="arrow-up-right" size={14} />
          </button>
          <div className="nav-locale">
            <button className={lang === 'ES' ? 'on' : ''} onClick={() => handleLang('ES')}>ES</button>
            <span style={{ color: 'var(--fg-mute)' }}>/</span>
            <button className={lang === 'EN' ? 'on' : ''} onClick={() => handleLang('EN')}>EN</button>
          </div>
        </div>

        {/* theme-toggle hidden — dark mode preserved for future use
        <button
          className="theme-toggle"
          onClick={toggleTheme}
          aria-label={theme === 'light' ? 'Cambiar a modo oscuro' : 'Cambiar a modo claro'}
        >
          <Icon name={theme === 'light' ? 'moon' : 'sun'} size={18} />
        </button>
        */}

        <button className="nav-burger" onClick={() => setMenuOpen(!menuOpen)} aria-label="menu">
          <span style={menuOpen ? { transform: 'rotate(45deg) translateY(4px)' } : {}} />
          <span style={menuOpen ? { opacity: 0 } : {}} />
          <span style={menuOpen ? { transform: 'rotate(-45deg) translateY(-4px)' } : {}} />
        </button>
      </nav>

      <div className={`mobile-menu ${menuOpen ? 'open' : ''}`}>
        {items.map((it) => (
          <a
            key={it.id}
            className={page === it.id ? 'active' : ''}
            onClick={(e) => { e.preventDefault(); setPage(it.id); }}
          >
            {it.label}
          </a>
        ))}
      </div>
    </React.Fragment>
  );
}

// ----- Footer -----
function Footer({ setPage }) {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-grid">
          <div>
            <div className="footer-brand-name"><em>ATS</em></div>
            <p className="footer-tag">Asesoría y soluciones en impuestos. Más de 20 años acompañando operaciones nacionales e internacionales.</p>
            <div style={{ marginTop: 24 }}>
              <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, letterSpacing: '0.18em', color: 'var(--fg-mute)', textTransform: 'uppercase' }}>Redes Sociales</span>
              <div className="footer-social" style={{ marginTop: 8 }}>
                <a href="https://www.linkedin.com/company/atstaxconsulting/" target="_blank" rel="noreferrer" aria-label="LinkedIn"><Icon name="linkedin" size={18} /></a>
              </div>
            </div>
          </div>

          <div>
            <h4>Firma</h4>
            <a className="footer-link" onClick={() => setPage('nosotros')}>Nosotros</a>
            <a className="footer-link" onClick={() => setPage('servicios')}>Servicios</a>
            <a className="footer-link" onClick={() => setPage('contacto')}>Contacto</a>
            <a className="footer-link" onClick={() => setPage('privacidad')} style={{ cursor: 'pointer' }}>Aviso de Privacidad</a>
          </div>

          <div>
            <h4>Sedes</h4>
            <a className="footer-link" onClick={() => setPage('contacto')}>Ciudad de México</a>
            <a className="footer-link" onClick={() => setPage('contacto')}>Bajío</a>
          </div>

          <div>
            <h4>Ligas de Interés</h4>
            <a className="footer-link" href="https://www.sat.gob.mx" target="_blank" rel="noreferrer">SAT</a>
            <a className="footer-link" href="https://www.sat.gob.mx" target="_blank" rel="noreferrer">Tablas e Indicadores</a>
            <a className="footer-link" href="https://dof.gob.mx" target="_blank" rel="noreferrer">DOF</a>
            <a className="footer-link" href="https://www.prodecon.gob.mx" target="_blank" rel="noreferrer">PRODECON</a>
          </div>
        </div>

        <div className="footer-bottom">
          <span>© {new Date().getFullYear()} ATS Asesoría y Soluciones en Impuestos · Todos los derechos reservados</span>
          <span>MX · CDMX / Bajío</span>
        </div>
      </div>
    </footer>
  );
}

window.useReveal = useReveal;
window.Nav = Nav;
window.Footer = Footer;
