/* global React, ReactDOM, window */
const { useState: useStateApp, useEffect: useEffectApp } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "dark"
}/*EDITMODE-END*/;

function App() {
  const [page, setPage] = useStateApp('home');
  const [selectedService, setSelectedService] = useStateApp(null);
  const [tweaks, setTweak] = window.useTweaks(TWEAK_DEFAULTS);

  // Apply theme
  useEffectApp(() => {
    document.documentElement.setAttribute('data-theme', tweaks.theme || 'dark');
  }, [tweaks.theme]);

  const setPageAndReset = (p) => {
    setPage(p);
    if (p !== 'servicios') setSelectedService(null);
  };

  const openService = (id) => {
    setSelectedService(id);
    setPage('servicios');
  };

  return (
    <div className="app">
      <div className="bg-grid" />
      <window.Nav page={page} setPage={setPageAndReset} />

      {page === 'home' && <window.HomePage setPage={setPageAndReset} openService={openService} />}
      {page === 'nosotros' && <window.NosotrosPage setPage={setPageAndReset} />}
      {page === 'servicios' && <window.ServiciosPage setPage={setPageAndReset} selected={selectedService} setSelected={setSelectedService} />}
      {page === 'contacto' && <window.ContactoPage />}

      <window.Footer setPage={setPageAndReset} />

      <window.TweaksPanel title="Tweaks">
        <window.TweakSection label="Apariencia">
          <window.TweakRadio
            label="Tema"
            value={tweaks.theme}
            onChange={(v) => setTweak('theme', v)}
            options={[
              { value: 'dark', label: 'Oscuro' },
              { value: 'light', label: 'Claro' },
            ]}
          />
        </window.TweakSection>
      </window.TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
