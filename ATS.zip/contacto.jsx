/* global React, window */
const { useState: useStateC } = React;
const { Icon: IconC, useReveal: useRevealC } = window;

function ContactoPage() {
  useRevealC();
  const [form, setForm] = useStateC({ name: '', email: '', company: '', service: '', message: '' });
  const [sent, setSent] = useStateC(false);

  const onChange = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const onSubmit = (e) => {
    e.preventDefault();
    setSent(true);
  };

  return (
    <div className="page-enter" data-screen-label="04 Contacto">
      <section className="svc-hero">
        <div className="container">
          <div className="eyebrow reveal" style={{ marginBottom: 40 }}>/ Contacto</div>
          <h1 className="about-hero-title reveal serif">
            Hablemos de<br /><em>tu operación.</em>
          </h1>
          <p className="section-lead reveal d1" style={{ marginTop: 32, maxWidth: '60ch' }}>
            Cuéntanos brevemente sobre tu empresa y el reto fiscal que estás enfrentando. Respondemos en menos de 24 horas hábiles.
          </p>
        </div>
      </section>

      <section className="section" style={{ paddingTop: 60 }}>
        <div className="container">
          <div className="contact-grid">
            <div className="reveal">
              <div className="eyebrow" style={{ marginBottom: 32 }}>/ 01 · Escríbenos</div>

              {sent ? (
                <div className="contact-success page-enter">
                  <h4>Gracias por escribirnos.</h4>
                  <p style={{ color: 'var(--fg-dim)' }}>
                    Hemos recibido tu mensaje. Un miembro del equipo te contactará pronto{form.name ? `, ${form.name}` : ''}.
                  </p>
                  <button
                    onClick={() => { setSent(false); setForm({ name: '', email: '', company: '', service: '', message: '' }); }}
                    className="btn btn-ghost"
                    style={{ marginTop: 24 }}
                  >
                    Enviar otro mensaje
                  </button>
                </div>
              ) : (
                <form className="contact-form" onSubmit={onSubmit}>
                  <div className="field-row">
                    <div className="field">
                      <label>Nombre completo</label>
                      <input required value={form.name} onChange={onChange('name')} placeholder="María González" />
                    </div>
                    <div className="field">
                      <label>Empresa</label>
                      <input value={form.company} onChange={onChange('company')} placeholder="Razón social" />
                    </div>
                  </div>
                  <div className="field-row">
                    <div className="field">
                      <label>Email corporativo</label>
                      <input required type="email" value={form.email} onChange={onChange('email')} placeholder="maria@empresa.com" />
                    </div>
                    <div className="field">
                      <label>Servicio de interés</label>
                      <select value={form.service} onChange={onChange('service')} style={{ color: form.service ? 'var(--fg)' : 'var(--fg-mute)' }}>
                        <option value="">Selecciona…</option>
                        <option value="impuestos-corporativos">Impuestos Corporativos</option>
                        <option value="legal">Legal</option>
                        <option value="cumplimiento">Cumplimiento</option>
                        <option value="contribuciones-locales">Contribuciones Locales</option>
                        <option value="comercio-exterior">Comercio Exterior</option>
                        <option value="capital-humano">Capital Humano</option>
                      </select>
                    </div>
                  </div>
                  <div className="field">
                    <label>Cuéntanos</label>
                    <textarea required value={form.message} onChange={onChange('message')} placeholder="Sector, tipo de operación, urgencia, contexto…" />
                  </div>

                  <div style={{ marginTop: 16, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 16 }}>
                    <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, letterSpacing: '0.16em', color: 'var(--fg-mute)', textTransform: 'uppercase' }}>
                      Tus datos son confidenciales
                    </span>
                    <button className="btn btn-primary" type="submit">
                      Enviar mensaje <span className="btn-arrow">→</span>
                    </button>
                  </div>
                </form>
              )}
            </div>

            <div className="reveal d1">
              <div className="eyebrow" style={{ marginBottom: 32 }}>/ 02 · Visítanos</div>

              <div className="locations">
                <div className="location">
                  <div className="location-tag">Sede principal</div>
                  <h3 className="serif">Ciudad de México</h3>
                  <p style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
                    <IconC name="pin" size={16} />
                    Av. Insurgentes Sur 1457<br />Col. Insurgentes Mixcoac, 03920
                  </p>
                  <p style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    <IconC name="phone" size={16} />+52 (55) 5000 0000
                  </p>
                  <p style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    <IconC name="mail" size={16} />cdmx@atsconsulting.mx
                  </p>
                </div>

                <div className="location">
                  <div className="location-tag">Oficina regional</div>
                  <h3 className="serif">Bajío</h3>
                  <p style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
                    <IconC name="pin" size={16} />
                    Blvd. Adolfo López Mateos 2475<br />Col. Las Reynas, León, Gto. 37549
                  </p>
                  <p style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    <IconC name="phone" size={16} />+52 (477) 000 0000
                  </p>
                  <p style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    <IconC name="mail" size={16} />bajio@atsconsulting.mx
                  </p>
                </div>

                <div style={{ padding: '24px 0', borderTop: '1px solid var(--line)', display: 'flex', flexDirection: 'column', gap: 8 }}>
                  <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, letterSpacing: '0.18em', color: 'var(--gold)', textTransform: 'uppercase' }}>Horario</span>
                  <p style={{ color: 'var(--fg)', fontSize: 15 }}>Lunes a viernes · 9:00 – 18:00 hrs</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

window.ContactoPage = ContactoPage;
