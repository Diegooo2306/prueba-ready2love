/* global window */

const SERVICES = [
  {
    id: 'impuestos-corporativos',
    num: '01',
    title: 'Impuestos Corporativos',
    short: 'Estrategias para eficientar la carga tributaria.',
    desc: 'Diseñamos estrategias para eficientar la carga tributaria de nuestros clientes en armonía con el marco regulatorio y con el objetivo de mejorar la tasa efectiva de impuestos.',
    points: [
      'Planeación fiscal corporativa',
      'Estructuras de inversión nacional e internacional',
      'Optimización de tasa efectiva',
      'Revisión de obligaciones fiscales',
      'Estudios de precios de transferencia',
    ],
  },
  {
    id: 'legal',
    num: '02',
    title: 'Legal',
    short: 'Certeza jurídica corporativa y fiscal.',
    desc: 'Proporcionamos certeza jurídica a las operaciones de nuestros clientes en el ámbito corporativo y fiscal.',
    points: [
      'Asesoría corporativa',
      'Contratos y convenios',
      'Litigio fiscal',
      'Medios de defensa',
      'Consultas y orientación normativa',
    ],
  },
  {
    id: 'cumplimiento',
    num: '03',
    title: 'Cumplimiento',
    short: 'Procesamiento contable y fiscal preciso.',
    desc: 'Apoyamos a nuestros clientes en labores de cumplimiento como procesamiento contable de las transacciones de la entidad.',
    points: [
      'Contabilidad y cierre mensual',
      'Determinación de impuestos',
      'Presentación de declaraciones',
      'Reportes regulatorios',
      'Conciliaciones y auditorías',
    ],
  },
  {
    id: 'contribuciones-locales',
    num: '04',
    title: 'Contribuciones Locales',
    short: 'Obligaciones estatales y municipales.',
    desc: 'Proporcionamos asesoría en el cumplimiento de obligaciones y carga fiscal que los estados imponen a los contribuyentes como el impuesto sobre nómina, hospedaje, predial, derechos de agua, sobre extracción de materiales del subsuelo, entre otros.',
    points: [
      'Impuesto sobre nómina',
      'Hospedaje y predial',
      'Derechos de agua',
      'Extracción de materiales',
      'Cumplimiento estatal y municipal',
    ],
  },
  {
    id: 'comercio-exterior',
    num: '05',
    title: 'Comercio Exterior',
    short: 'Aduanas y operaciones internacionales.',
    desc: 'Proporcionamos asesoría relacionada con el cumplimiento de obligaciones y carga fiscal de las contribuciones relacionadas con el comercio exterior y aduanas.',
    points: [
      'Clasificación arancelaria',
      'Programas IMMEX y PROSEC',
      'Operaciones aduanales',
      'Tratados de libre comercio',
      'Asesoría en importación y exportación',
    ],
  },
  {
    id: 'capital-humano',
    num: '06',
    title: 'Capital Humano',
    short: 'Carga fiscal del talento.',
    desc: 'Proporcionamos asesoría en el cumplimiento de obligaciones y carga fiscal relacionada con el capital humano como son la emisión de informes y dictámenes.',
    points: [
      'Dictamen de seguridad social',
      'Compensaciones ejecutivas',
      'Expatriados y movilidad',
      'Outsourcing y REPSE',
      'Cumplimiento de seguridad social',
    ],
  },
];

const ENFOQUE = [
  {
    num: '01',
    title: 'Entendimiento',
    text: 'Comprendemos el negocio de nuestros clientes y creamos soluciones acorde con sus intereses. Cada propuesta nace de un análisis profundo del contexto, industria y objetivos de la empresa.',
  },
  {
    num: '02',
    title: 'Prontitud',
    text: 'Tenemos capacidad de respuesta, inmediata y con calidad. La velocidad sin precisión no sirve; la precisión sin velocidad se queda corta. Operamos en la intersección.',
  },
  {
    num: '03',
    title: 'Integridad',
    text: 'Creamos, actuamos y exponemos nuestro punto de vista con ética. La confianza es la base de toda relación profesional y la cuidamos en cada interacción.',
  },
  {
    num: '04',
    title: 'Servicio y Experiencia',
    text: 'Brindamos un servicio de calidad. Contar con profesionales con experiencia es esencial para lograrlo: más de 16 años en operaciones nacionales e internacionales.',
  },
  {
    num: '05',
    title: 'Cercanía',
    text: 'Buscamos una comunicación efectiva, interactuamos para crear una relación de negocios con nuestros clientes. No somos un proveedor, somos un socio.',
  },
];

const INDUSTRIES = [
  'Manufactura',
  'Consumo',
  'Bienes Raíces',
  'Construcción',
  'Hotelería',
  'Energía',
];

const STATS = [
  { num: '16', suffix: '+', label: 'Años de experiencia' },
  { num: '6', suffix: '', label: 'Industrias clave' },
  { num: '2', suffix: '', label: 'Sedes en México' },
  { num: '100', suffix: '%', label: 'Compromiso ético' },
];

window.ATS_DATA = { SERVICES, ENFOQUE, INDUSTRIES, STATS };
