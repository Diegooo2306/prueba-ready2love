/* global React, window */
const { useReveal: useRevealN } = window;

function NosotrosPage({ setPage }) {
  useRevealN();
  return (
    <div className="page-enter" data-screen-label="02 Nosotros">
      {/* Hero */}
      <section className="about-hero">
        <div className="container">
          <div className="eyebrow reveal" style={{ marginBottom: 40 }}>/ La firma · ATS Consulting</div>
          <div className="about-hero-grid">
            <h1 className="about-hero-title reveal serif">
              Más de 16 años<br />asesorando<br /><em>con propósito.</em>
            </h1>
            <div className="about-meta reveal d1">
              <div className="about-meta-row"><span className="k">Fundada</span><span className="v">2008</span></div>
              <div className="about-meta-row"><span className="k">Sedes</span><span className="v">CDMX / Bajío</span></div>
              <div className="about-meta-row"><span className="k">Cobertura</span><span className="v">Nacional + Intl.</span></div>
              <div className="about-meta-row"><span className="k">Industrias</span><span className="v">06</span></div>
              <div className="about-meta-row"><span className="k">Servicios</span><span className="v">06</span></div>
              <div className="about-meta-row"><span className="k">Filosofía</span><span className="v">Ética · Cercanía</span></div>
            </div>
          </div>
        </div>
      </section>

      {/* Image band */}
      <section className="container">
        <div className="about-img-band">
          <div className="about-img reveal">
            <img src="https://images.unsplash.com/photo-1512813195386-6cf811ad3542?auto=format&fit=crop&w=2400&q=80" alt="CDMX" />
            <span className="about-img-cap">CDMX · Sede Principal</span>
          </div>
          <div className="about-img reveal d1">
            <img src="https://images.unsplash.com/photo-1518105779142-d975f22f1b0a?auto=format&fit=crop&w=2400&q=80" alt="Bajío" />
            <span className="about-img-cap">Bajío · Oficina</span>
          </div>
        </div>
      </section>

      {/* Manifesto */}
      <section className="section" style={{ borderTop: '1px solid var(--line)' }}>
        <div className="container">
          <div className="section-header">
            <div className="reveal">
              <div className="eyebrow" style={{ marginBottom: 24 }}>/ Manifiesto</div>
              <h2 className="section-title">Quiénes <em>somos.</em></h2>
            </div>
            <div className="reveal d1" style={{ fontSize: 20, color: 'var(--fg)', lineHeight: 1.55 }}>
              <p style={{ marginBottom: 20, color: 'var(--fg)' }}>
                ATS es una firma que proporciona soluciones de negocios con <em style={{ color: 'var(--gold)', fontFamily: 'Instrument Serif, serif' }}>experiencia, respuesta inmediata e integridad</em> en el ámbito fiscal.
              </p>
              <p style={{ marginBottom: 20 }}>
                Somos profesionales con más de 16 años enfocados en la asesoría de operaciones nacionales e internacionales. Comprendemos el negocio de nuestros clientes y creamos soluciones acorde con sus intereses.
              </p>
              <p>
                Nuestra competencia incluye las industrias de Manufactura, Consumo, Bienes Raíces, Construcción y Hotelería, y Energía.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Values grid */}
      <section className="section" style={{ paddingTop: 0 }}>
        <div className="container">
          <div className="values">
            {window.ATS_DATA.ENFOQUE.map((v, i) => (
              <div className="value reveal" style={{ transitionDelay: `${i * 0.08}s` }} key={i}>
                <div className="value-num">{v.num} / 05</div>
                <div className="value-title">{v.title}</div>
                <p className="value-text">{v.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Industries strip */}
      <section className="section" style={{ borderTop: '1px solid var(--line)' }}>
        <div className="container">
          <div className="section-header">
            <div className="reveal">
              <div className="eyebrow" style={{ marginBottom: 24 }}>/ Industrias</div>
              <h2 className="section-title">Sectores donde<br /><em>operamos.</em></h2>
            </div>
            <p className="section-lead reveal d1">
              Cada industria tiene su propio léxico fiscal. Conocemos el de las nuestras.
            </p>
          </div>

          <div className="reveal" style={{ borderTop: '1px solid var(--line)' }}>
            {window.ATS_DATA.INDUSTRIES.map((ind, i) => (
              <div key={i} style={{
                display: 'grid',
                gridTemplateColumns: '80px 1fr auto',
                gap: 32,
                padding: '28px 0',
                borderBottom: '1px solid var(--line)',
                alignItems: 'center',
                cursor: 'default',
                transition: 'padding 0.3s, background 0.3s',
              }}
              onMouseEnter={(e) => e.currentTarget.style.padding = '28px 16px'}
              onMouseLeave={(e) => e.currentTarget.style.padding = '28px 0'}
              >
                <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 12, color: 'var(--gold)', letterSpacing: '0.16em' }}>0{i + 1}</span>
                <span style={{ fontFamily: 'Instrument Serif, serif', fontSize: 40, letterSpacing: '-0.02em' }}>{ind}</span>
                <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, color: 'var(--fg-mute)', letterSpacing: '0.16em', textTransform: 'uppercase' }}>Industria</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="cta-section">
        <div className="container">
          <h2 className="cta-title reveal">Construyamos<br /><em>una relación.</em></h2>
          <p className="cta-text reveal d1">No buscamos clientes — buscamos socios de largo plazo en industrias que entendemos.</p>
          <div className="cta-buttons reveal d2">
            <button className="btn btn-primary" onClick={() => setPage('contacto')}>Contáctanos <span className="btn-arrow">→</span></button>
          </div>
        </div>
      </section>
    </div>
  );
}

window.NosotrosPage = NosotrosPage;
