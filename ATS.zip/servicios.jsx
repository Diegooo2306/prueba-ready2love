/* global React, window */
const { useReveal: useRevealS, Icon: IconS } = window;
const { SERVICES: SERVICES_S } = window.ATS_DATA;

function ServiciosPage({ setPage, selected, setSelected }) {
  useRevealS();

  if (selected) {
    const s = SERVICES_S.find((x) => x.id === selected);
    if (s) return <ServiceDetail s={s} setSelected={setSelected} setPage={setPage} />;
  }

  return (
    <div className="page-enter" data-screen-label="03 Servicios">
      <section className="svc-hero">
        <div className="container">
          <div className="eyebrow reveal" style={{ marginBottom: 40 }}>/ Servicios</div>
          <h1 className="about-hero-title reveal serif">
            Asesoría fiscal,<br />en seis <em>prácticas.</em>
          </h1>
          <p className="section-lead reveal d1" style={{ marginTop: 32, maxWidth: '60ch' }}>
            Articuladas para cubrir la operación completa: desde estrategia corporativa hasta cumplimiento local, comercio exterior y capital humano.
          </p>
        </div>
      </section>

      <section style={{ paddingBottom: 120 }}>
        <div className="container">
          <div className="svc-list">
            {SERVICES_S.map((s, i) => (
              <div key={s.id} className="svc-row reveal" style={{ transitionDelay: `${i * 0.05}s` }} onClick={() => setSelected(s.id)}>
                <div className="svc-row-num">{s.num}</div>
                <div className="svc-row-title">{s.title}</div>
                <div className="svc-row-desc">{s.short}</div>
                <div className="svc-row-arrow"><IconS name="arrow" size={20} /></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="cta-section">
        <div className="container">
          <h2 className="cta-title reveal">¿Qué servicio<br /><em>necesitas?</em></h2>
          <p className="cta-text reveal d1">Cuéntanos tu situación y diseñamos un alcance acorde a la operación.</p>
          <div className="cta-buttons reveal d2">
            <button className="btn btn-primary" onClick={() => setPage('contacto')}>Solicitar propuesta <span className="btn-arrow">→</span></button>
          </div>
        </div>
      </section>
    </div>
  );
}

function ServiceDetail({ s, setSelected, setPage }) {
  useRevealS();
  return (
    <div className="page-enter" data-screen-label={`03 Servicio · ${s.title}`}>
      <section className="svc-hero">
        <div className="container">
          <button
            onClick={() => setSelected(null)}
            style={{
              fontFamily: 'JetBrains Mono, monospace',
              fontSize: 12,
              letterSpacing: '0.14em',
              color: 'var(--fg-mute)',
              marginBottom: 40,
              textTransform: 'uppercase',
              display: 'inline-flex',
              gap: 8,
              alignItems: 'center',
            }}
          >
            ← Volver a servicios
          </button>

          <div className="eyebrow reveal" style={{ marginBottom: 32 }}>/ {s.num} · Servicio</div>
          <h1 className="about-hero-title reveal serif">
            <em>{s.title}</em>
          </h1>
          <p className="section-lead reveal d1" style={{ marginTop: 32, maxWidth: '60ch', fontSize: 20 }}>
            {s.desc}
          </p>
        </div>
      </section>

      <section className="section" style={{ borderTop: '1px solid var(--line)' }}>
        <div className="container">
          <div className="section-header">
            <div className="reveal">
              <div className="eyebrow" style={{ marginBottom: 24 }}>/ Alcance</div>
              <h2 className="section-title">Qué <em>incluye.</em></h2>
            </div>
            <p className="section-lead reveal d1">
              Una lista no exhaustiva de las áreas que cubre esta práctica. El alcance se ajusta a cada cliente.
            </p>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 16 }}>
            {s.points.map((p, i) => (
              <div key={i} className="value reveal" style={{ transitionDelay: `${i * 0.06}s`, padding: '32px 28px', minHeight: 'auto' }}>
                <div className="value-num">{String(i + 1).padStart(2, '0')}</div>
                <div className="value-title" style={{ fontSize: 22 }}>{p}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Other services */}
      <section className="section" style={{ paddingTop: 0 }}>
        <div className="container">
          <div className="section-header">
            <div className="reveal">
              <div className="eyebrow" style={{ marginBottom: 24 }}>/ Más prácticas</div>
              <h2 className="section-title">Otros <em>servicios.</em></h2>
            </div>
          </div>
          <div className="svc-list" style={{ borderTop: '1px solid var(--line)' }}>
            {SERVICES_S.filter((x) => x.id !== s.id).map((other) => (
              <div key={other.id} className="svc-row" onClick={() => setSelected(other.id)}>
                <div className="svc-row-num">{other.num}</div>
                <div className="svc-row-title">{other.title}</div>
                <div className="svc-row-desc">{other.short}</div>
                <div className="svc-row-arrow"><IconS name="arrow" size={20} /></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="cta-section">
        <div className="container">
          <h2 className="cta-title reveal">¿Te interesa<br /><em>esta práctica?</em></h2>
          <div className="cta-buttons reveal d1">
            <button className="btn btn-primary" onClick={() => setPage('contacto')}>Contáctanos <span className="btn-arrow">→</span></button>
          </div>
        </div>
      </section>
    </div>
  );
}

window.ServiciosPage = ServiciosPage;
