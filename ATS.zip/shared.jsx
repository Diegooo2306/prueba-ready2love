/* global React, window */
const { useState, useEffect, useRef } = React;
const { Icon } = window;

// ----- useReveal: IntersectionObserver-based scroll reveal -----
function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll('.reveal:not(.in)');
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add('in');
            io.unobserve(e.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -80px 0px' }
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  });
}

// ----- Nav -----
function Nav({ page, setPage }) {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [lang, setLang] = useState('ES');

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [page]);

  const items = [
    { id: 'home', label: 'Inicio' },
    { id: 'nosotros', label: 'Nosotros' },
    { id: 'servicios', label: 'Servicios' },
    { id: 'contacto', label: 'Contacto' },
  ];

  return (
    <React.Fragment>
      <nav className={`nav ${scrolled ? 'scrolled' : ''}`}>
        <div className="brand" onClick={() => setPage('home')}>
          <div className="brand-mark" aria-label="ATS logo">
            <svg viewBox="0 0 56 40" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <linearGradient id="ats-dot-1" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0" stopColor="#FB2A19"/>
                  <stop offset="1" stopColor="#FF4A1F"/>
                </linearGradient>
                <linearGradient id="ats-dot-2" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0" stopColor="#FF5A23"/>
                  <stop offset="1" stopColor="#FF7A28"/>
                </linearGradient>
                <linearGradient id="ats-dot-3" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0" stopColor="#FF8A3D"/>
                  <stop offset="1" stopColor="#FFA552"/>
                </linearGradient>
              </defs>
              <circle className="dot dot-1" cx="14" cy="16" r="7.5" fill="url(#ats-dot-1)"/>
              <circle className="dot dot-2" cx="32" cy="10" r="7.5" fill="url(#ats-dot-2)"/>
              <circle className="dot dot-3" cx="26" cy="28" r="6" fill="url(#ats-dot-3)"/>
            </svg>
          </div>
          <div className="brand-text">
            <span className="brand-name">ATS</span>
            <span className="brand-sub">Consulting</span>
          </div>
        </div>

        <div className="nav-links">
          {items.map((it) => (
            <button
              key={it.id}
              className={`nav-link ${page === it.id ? 'active' : ''}`}
              onClick={() => setPage(it.id)}
            >
              {it.label}
            </button>
          ))}
          <button className="nav-cta" onClick={() => setPage('contacto')}>
            Contáctanos <Icon name="arrow-up-right" size={14} />
          </button>
          <div className="nav-locale">
            <button className={lang === 'ES' ? 'on' : ''} onClick={() => setLang('ES')}>ES</button>
            <span style={{ color: 'var(--fg-mute)' }}>/</span>
            <button className={lang === 'EN' ? 'on' : ''} onClick={() => setLang('EN')}>EN</button>
          </div>
        </div>

        <button className="nav-burger" onClick={() => setMenuOpen(!menuOpen)} aria-label="menu">
          <span style={menuOpen ? { transform: 'rotate(45deg) translateY(4px)' } : {}} />
          <span style={menuOpen ? { opacity: 0 } : {}} />
          <span style={menuOpen ? { transform: 'rotate(-45deg) translateY(-4px)' } : {}} />
        </button>
      </nav>

      <div className={`mobile-menu ${menuOpen ? 'open' : ''}`}>
        {items.map((it) => (
          <a
            key={it.id}
            className={page === it.id ? 'active' : ''}
            onClick={(e) => { e.preventDefault(); setPage(it.id); }}
          >
            {it.label}
          </a>
        ))}
      </div>
    </React.Fragment>
  );
}

// ----- Footer -----
function Footer({ setPage }) {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-grid">
          <div>
            <div className="footer-brand-name">ATS <em>Consulting</em></div>
            <p className="footer-tag">Asesoría y soluciones en impuestos. Más de 16 años acompañando operaciones nacionales e internacionales.</p>
            <div className="footer-social">
              <a href="#" aria-label="LinkedIn"><Icon name="arrow-up-right" size={14} /></a>
              <a href="#" aria-label="Twitter"><Icon name="arrow-up-right" size={14} /></a>
              <a href="#" aria-label="Facebook"><Icon name="arrow-up-right" size={14} /></a>
            </div>
          </div>

          <div>
            <h4>Firma</h4>
            <a className="footer-link" onClick={() => setPage('nosotros')}>Nosotros</a>
            <a className="footer-link" onClick={() => setPage('servicios')}>Servicios</a>
            <a className="footer-link" onClick={() => setPage('contacto')}>Contacto</a>
            <a className="footer-link" href="#">Aviso de Privacidad</a>
          </div>

          <div>
            <h4>Sedes</h4>
            <a className="footer-link" onClick={() => setPage('contacto')}>Ciudad de México</a>
            <a className="footer-link" onClick={() => setPage('contacto')}>Bajío</a>
          </div>

          <div>
            <h4>Ligas de Interés</h4>
            <a className="footer-link" href="https://www.sat.gob.mx" target="_blank" rel="noreferrer">SAT</a>
            <a className="footer-link" href="https://www.sat.gob.mx" target="_blank" rel="noreferrer">Tablas e Indicadores</a>
            <a className="footer-link" href="https://dof.gob.mx" target="_blank" rel="noreferrer">DOF</a>
            <a className="footer-link" href="https://www.prodecon.gob.mx" target="_blank" rel="noreferrer">PRODECON</a>
          </div>
        </div>

        <div className="footer-bottom">
          <span>© 2026 ATS Asesoría y Soluciones en Impuestos · Todos los derechos reservados</span>
          <span>MX · CDMX / Bajío</span>
        </div>
      </div>
    </footer>
  );
}

window.useReveal = useReveal;
window.Nav = Nav;
window.Footer = Footer;
