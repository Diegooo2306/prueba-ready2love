/* Quiniela 2026 — Main App */

function App() {
  const [loggedIn, setLoggedIn] = React.useState(false);
  const [view, setView] = React.useState("dashboard");
  const [pickingMatch, setPickingMatch] = React.useState(null);
  const [predictions, setPredictions] = React.useState(window.CURRENT_PREDICTIONS);
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  // Keep predictions in sync with window
  React.useEffect(() => { window.CURRENT_PREDICTIONS = predictions; }, [predictions]);

  function handlePickMatch(match) {
    setPickingMatch(match);
  }

  function handleSavePrediction(pred) {
    setPredictions(prev => ({ ...prev, [pred.matchId]: pred }));
    setPickingMatch(null);
  }

  function handleNav(v) {
    setView(v);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  if (!loggedIn) {
    return <LoginScreen onLogin={() => setLoggedIn(true)} />;
  }

  const u = window.CURRENT_USER;
  const navItems = [
    { id: "dashboard", label: "Inicio" },
    { id: "matches", label: "Partidos" },
    { id: "history", label: "Mi historial" },
    { id: "leaderboard", label: "Ranking" },
    { id: "profile", label: "Perfil" },
  ];

  return (
    <div className="app">
      <header className="topbar">
        <div className="shell topbar-row">
          <Logo />
          <nav className="nav">
            {navItems.map(n => (
              <button
                key={n.id}
                className={`nav-item ${view === n.id ? "active" : ""}`}
                onClick={() => handleNav(n.id)}
              >
                {n.label}
              </button>
            ))}
          </nav>
          <div className="topbar-spacer"></div>
          <div className="lockbadge">
            <span className="dot"></span>
            <span className="label">Cierre en</span>
            <strong>28 días</strong>
          </div>
          <div className="user-chip">
            <Avatar initials={u.avatar.initials} color={u.avatar.color} size={32} />
            <div className="flex-col" style={{ lineHeight: 1.1 }}>
              <span style={{ fontSize: 13, fontWeight: 600, color: "#fff" }}>{u.name.split(" ")[0]}</span>
              <span style={{ fontSize: 11, color: "#b9ac8e" }}>{u.company.split(" ")[0]}</span>
            </div>
          </div>
          <button className="menu-btn" onClick={() => setMobileMenuOpen(o => !o)} aria-label="Menu">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M3 6h18M3 12h18M3 18h18"/></svg>
          </button>
        </div>
      </header>

      {mobileMenuOpen && (
        <div className="mobile-nav open">
          {navItems.map(n => (
            <button
              key={n.id}
              className={`nav-item ${view === n.id ? "active" : ""}`}
              onClick={() => handleNav(n.id)}
            >
              {n.label}
            </button>
          ))}
        </div>
      )}

      <main style={{ flex: 1 }}>
        {view === "dashboard" && <Dashboard onNav={handleNav} onPickMatch={handlePickMatch} />}
        {view === "matches" && <MatchesScreen onPickMatch={handlePickMatch} />}
        {view === "history" && <HistoryScreen onPickMatch={handlePickMatch} />}
        {view === "leaderboard" && <LeaderboardScreen />}
        {view === "profile" && <ProfileScreen />}
      </main>

      <footer className="footer">
        <div className="shell">
          Quiniela Corporativa Mundial 2026 · Mantic Consulting × GR Plastic · Reglamento interno v3.1
        </div>
      </footer>

      {pickingMatch && (
        <PredictionModal
          match={pickingMatch}
          prediction={predictions[pickingMatch.id]}
          onClose={() => setPickingMatch(null)}
          onSave={handleSavePrediction}
        />
      )}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
