/* Quiniela 2026 — Shared UI Components */

function Flag({ iso, size = "md" }) {
  return (
    <span className={`flag ${size}`}>
      <img src={window.flagUrl(iso)} alt="" loading="lazy" />
    </span>
  );
}

function Avatar({ initials, color, size = 36 }) {
  return (
    <span className="avatar" style={{ background: color, width: size, height: size, fontSize: size * 0.36 }}>
      {initials}
    </span>
  );
}

function Logo() {
  return (
    <div className="brand">
      <div className="brand-mark"></div>
      <div className="brand-text">
        <span>Quiniela 2026</span>
        <small>Mantic × GR Plastic</small>
      </div>
    </div>
  );
}

function useCountdown(targetIso) {
  const [now, setNow] = React.useState(() => window.APP_NOW.getTime());
  React.useEffect(() => {
    const id = setInterval(() => {
      // simulate clock ticking from APP_NOW
      setNow(n => n + 1000);
    }, 1000);
    return () => clearInterval(id);
  }, []);
  const target = new Date(targetIso).getTime();
  const diff = Math.max(0, target - now);
  const days = Math.floor(diff / 86400000);
  const hours = Math.floor((diff % 86400000) / 3600000);
  const minutes = Math.floor((diff % 3600000) / 60000);
  const seconds = Math.floor((diff % 60000) / 1000);
  return { days, hours, minutes, seconds, totalMs: diff };
}

function CountdownBlocks({ targetIso }) {
  const { days, hours, minutes, seconds } = useCountdown(targetIso);
  const pad = n => String(n).padStart(2, "0");
  return (
    <div className="countdown-blocks">
      <div className="cd-block"><div className="num">{pad(days)}</div><div className="lab">Días</div></div>
      <div className="cd-block"><div className="num">{pad(hours)}</div><div className="lab">Horas</div></div>
      <div className="cd-block"><div className="num">{pad(minutes)}</div><div className="lab">Min</div></div>
      <div className="cd-block"><div className="num">{pad(seconds)}</div><div className="lab">Seg</div></div>
    </div>
  );
}

function Progress({ value, max }) {
  const pct = Math.min(100, Math.round((value / max) * 100));
  return (
    <div className="progress" aria-label={`${pct}%`}>
      <span style={{ width: `${pct}%` }}></span>
    </div>
  );
}

function MatchRow({ match, prediction, onClick }) {
  const home = window.TEAMS[match.home];
  const away = window.TEAMS[match.away];
  const d = new Date(match.kickoff);
  const days = ["Dom","Lun","Mar","Mié","Jue","Vie","Sáb"];
  const months = ["ene","feb","mar","abr","may","jun","jul","ago","sep","oct","nov","dic"];
  const dateStr = `${days[d.getDay()]} ${d.getDate()} ${months[d.getMonth()]}`;
  const timeStr = `${String(d.getHours()).padStart(2,"0")}:${String(d.getMinutes()).padStart(2,"0")}`;

  let pickEl;
  if (!prediction) {
    pickEl = <span className="match-pick empty">Sin pronóstico →</span>;
  } else {
    const winnerCode = prediction.winner === "draw" ? "Empate" : window.TEAMS[prediction.winner === "home" ? match.home : match.away].code;
    pickEl = (
      <span className="match-pick set">
        Tu pick: {winnerCode}
        {prediction.withScore && prediction.score && (
          <span style={{ marginLeft: 6, color: "var(--muted)", fontWeight: 600 }}>
            {prediction.score.h}–{prediction.score.a}
          </span>
        )}
      </span>
    );
  }

  return (
    <div className="match-row" onClick={onClick}>
      <div className="match-time">
        <strong>{dateStr}</strong>
        {timeStr}
      </div>
      <div className="match-teams">
        <div className="match-team">
          <Flag iso={home.iso} size="sm" />
          <span className="code">{home.code}</span>
        </div>
        <div className="match-vs">vs</div>
        <div className="match-team right">
          <span className="code">{away.code}</span>
          <Flag iso={away.iso} size="sm" />
        </div>
      </div>
      <div>{pickEl}</div>
    </div>
  );
}

/* Prediction Modal */
function PredictionModal({ match, prediction, onClose, onSave }) {
  const home = window.TEAMS[match.home];
  const away = window.TEAMS[match.away];

  const [winner, setWinner] = React.useState(prediction?.winner || null);
  const [withScore, setWithScore] = React.useState(prediction?.withScore || false);
  const [h, setH] = React.useState(prediction?.score?.h ?? 1);
  const [a, setA] = React.useState(prediction?.score?.a ?? 1);

  // Sync score with winner if both set
  function adjustScore(newH, newA) {
    setH(Math.max(0, Math.min(9, newH)));
    setA(Math.max(0, Math.min(9, newA)));
  }

  // Validate: if withScore, the score must match the winner
  const scoreMatchesWinner = !withScore || (
    (winner === "home" && h > a) ||
    (winner === "away" && h < a) ||
    (winner === "draw" && h === a)
  );

  const d = new Date(match.kickoff);
  const days = ["Dom","Lun","Mar","Mié","Jue","Vie","Sáb"];
  const months = ["ene","feb","mar","abr","may","jun","jul","ago","sep","oct","nov","dic"];
  const dateStr = `${days[d.getDay()]} ${d.getDate()} de ${months[d.getMonth()]} · ${String(d.getHours()).padStart(2,"0")}:${String(d.getMinutes()).padStart(2,"0")}`;

  function handleSave() {
    if (!winner) return;
    onSave({
      matchId: match.id,
      winner,
      withScore,
      score: withScore ? { h, a } : null,
    });
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-head">
          <div className="eyebrow">Grupo {match.group} · Jornada {match.matchday}</div>
          <div className="versus">
            <div className="versus-team">
              <Flag iso={home.iso} size="xl" />
              <div className="name">{home.name}</div>
              <div className="code">{home.code}</div>
            </div>
            <div className="versus-vs">VS</div>
            <div className="versus-team">
              <Flag iso={away.iso} size="xl" />
              <div className="name">{away.name}</div>
              <div className="code">{away.code}</div>
            </div>
          </div>
          <div className="meta">
            <span>📅 {dateStr}</span>
            <span>📍 {match.city}</span>
          </div>
        </div>
        <div className="modal-body">
          <div className="eyebrow" style={{ marginBottom: 10 }}>¿Quién gana?</div>
          <div className="pick-options">
            <div
              className={`pick-opt ${winner === "home" ? "active" : ""}`}
              onClick={() => setWinner("home")}
            >
              <Flag iso={home.iso} size="md" />
              <div className="who" style={{ marginTop: 6 }}>{home.code}<small>{home.name}</small></div>
            </div>
            <div
              className={`pick-opt ${winner === "draw" ? "active" : ""}`}
              onClick={() => setWinner("draw")}
            >
              <div style={{ fontFamily: "var(--display)", fontSize: 28, fontWeight: 800, color: "var(--muted)" }}>=</div>
              <div className="who" style={{ marginTop: 6 }}>Empate<small>Sin ganador</small></div>
            </div>
            <div
              className={`pick-opt ${winner === "away" ? "active" : ""}`}
              onClick={() => setWinner("away")}
            >
              <Flag iso={away.iso} size="md" />
              <div className="who" style={{ marginTop: 6 }}>{away.code}<small>{away.name}</small></div>
            </div>
          </div>

          <div className="score-block">
            <label className="score-toggle" onClick={() => setWithScore(s => !s)}>
              <span className={`switch ${withScore ? "on" : ""}`}></span>
              <span><b>Pronosticar marcador exacto</b> — bonus +3 pts si aciertas</span>
            </label>

            {withScore && (
              <div style={{ marginTop: 16 }}>
                <div className="score-row">
                  <div className="score-picker">
                    <div className="team-mini"><Flag iso={home.iso} size="sm" />{home.code}</div>
                    <div className="score-display">
                      <button className="score-btn" onClick={() => adjustScore(h - 1, a)}>−</button>
                      <span className="score-num">{h}</span>
                      <button className="score-btn" onClick={() => adjustScore(h + 1, a)}>+</button>
                    </div>
                  </div>
                  <div className="score-divider">–</div>
                  <div className="score-picker">
                    <div className="team-mini"><Flag iso={away.iso} size="sm" />{away.code}</div>
                    <div className="score-display">
                      <button className="score-btn" onClick={() => adjustScore(h, a - 1)}>−</button>
                      <span className="score-num">{a}</span>
                      <button className="score-btn" onClick={() => adjustScore(h, a + 1)}>+</button>
                    </div>
                  </div>
                </div>
                {!scoreMatchesWinner && winner && (
                  <div style={{ marginTop: 12, fontSize: 13, color: "var(--bad)" }}>
                    ⚠️ El marcador no coincide con el ganador que elegiste ({winner === "draw" ? "Empate" : window.TEAMS[winner === "home" ? match.home : match.away].name}).
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="bonus-banner">
            <div>🏆</div>
            <div>
              <b>Sistema de puntos:</b> 1 pt por acertar el ganador · +3 pts adicionales si aciertas también el marcador exacto.
            </div>
          </div>

          <div style={{ display: "flex", gap: 10, marginTop: 22 }}>
            <button className="btn btn-ghost" onClick={onClose}>Cancelar</button>
            <button
              className="btn btn-primary"
              style={{ flex: 1 }}
              disabled={!winner || !scoreMatchesWinner}
              onClick={handleSave}
            >
              {prediction ? "Actualizar pronóstico" : "Guardar pronóstico"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  Flag, Avatar, Logo, useCountdown, CountdownBlocks, Progress,
  MatchRow, PredictionModal,
});
