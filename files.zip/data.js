/* Quiniela Mundial 2026 — Data layer
   48 teams, 12 groups, 72 group-stage matches.
   Dates: June 11 – June 27, 2026 (group stage).
   App "today": May 11, 2026 — predictions open, lock on June 8 (3 days before kickoff). */

window.APP_NOW = new Date("2026-05-11T10:30:00-06:00"); // current "today" in app
window.LOCK_DATE = new Date("2026-06-08T00:00:00-06:00"); // 3 days before tournament starts
window.TOURNAMENT_START = new Date("2026-06-11T18:00:00-06:00");

window.TEAMS = {
  MEX: { code: "MEX", iso: "mx", name: "México" },
  CAN: { code: "CAN", iso: "ca", name: "Canadá" },
  USA: { code: "USA", iso: "us", name: "Estados Unidos" },
  ARG: { code: "ARG", iso: "ar", name: "Argentina" },
  BRA: { code: "BRA", iso: "br", name: "Brasil" },
  FRA: { code: "FRA", iso: "fr", name: "Francia" },
  ESP: { code: "ESP", iso: "es", name: "España" },
  ENG: { code: "ENG", iso: "gb-eng", name: "Inglaterra" },
  GER: { code: "GER", iso: "de", name: "Alemania" },
  POR: { code: "POR", iso: "pt", name: "Portugal" },
  NED: { code: "NED", iso: "nl", name: "Países Bajos" },
  ITA: { code: "ITA", iso: "it", name: "Italia" },
  CRO: { code: "CRO", iso: "hr", name: "Croacia" },
  BEL: { code: "BEL", iso: "be", name: "Bélgica" },
  URU: { code: "URU", iso: "uy", name: "Uruguay" },
  SUI: { code: "SUI", iso: "ch", name: "Suiza" },
  COL: { code: "COL", iso: "co", name: "Colombia" },
  SEN: { code: "SEN", iso: "sn", name: "Senegal" },
  MAR: { code: "MAR", iso: "ma", name: "Marruecos" },
  JPN: { code: "JPN", iso: "jp", name: "Japón" },
  KOR: { code: "KOR", iso: "kr", name: "Corea del Sur" },
  AUS: { code: "AUS", iso: "au", name: "Australia" },
  IRN: { code: "IRN", iso: "ir", name: "Irán" },
  DEN: { code: "DEN", iso: "dk", name: "Dinamarca" },
  POL: { code: "POL", iso: "pl", name: "Polonia" },
  SRB: { code: "SRB", iso: "rs", name: "Serbia" },
  ECU: { code: "ECU", iso: "ec", name: "Ecuador" },
  CRC: { code: "CRC", iso: "cr", name: "Costa Rica" },
  KSA: { code: "KSA", iso: "sa", name: "Arabia Saudita" },
  TUN: { code: "TUN", iso: "tn", name: "Túnez" },
  GHA: { code: "GHA", iso: "gh", name: "Ghana" },
  CMR: { code: "CMR", iso: "cm", name: "Camerún" },
  NGA: { code: "NGA", iso: "ng", name: "Nigeria" },
  ALG: { code: "ALG", iso: "dz", name: "Argelia" },
  EGY: { code: "EGY", iso: "eg", name: "Egipto" },
  QAT: { code: "QAT", iso: "qa", name: "Catar" },
  WAL: { code: "WAL", iso: "gb-wls", name: "Gales" },
  SWE: { code: "SWE", iso: "se", name: "Suecia" },
  NOR: { code: "NOR", iso: "no", name: "Noruega" },
  CHI: { code: "CHI", iso: "cl", name: "Chile" },
  PER: { code: "PER", iso: "pe", name: "Perú" },
  PAR: { code: "PAR", iso: "py", name: "Paraguay" },
  VEN: { code: "VEN", iso: "ve", name: "Venezuela" },
  TUR: { code: "TUR", iso: "tr", name: "Turquía" },
  UKR: { code: "UKR", iso: "ua", name: "Ucrania" },
  NZL: { code: "NZL", iso: "nz", name: "Nueva Zelanda" },
  CIV: { code: "CIV", iso: "ci", name: "Costa de Marfil" },
  JAM: { code: "JAM", iso: "jm", name: "Jamaica" },
};

window.GROUPS = {
  A: ["MEX", "NOR", "MAR", "KSA"],
  B: ["CAN", "BEL", "KOR", "CIV"],
  C: ["ESP", "SEN", "UKR", "CRC"],
  D: ["USA", "ITA", "WAL", "CMR"],
  E: ["FRA", "SUI", "EGY", "ECU"],
  F: ["ARG", "DEN", "TUN", "AUS"],
  G: ["BRA", "SWE", "IRN", "NZL"],
  H: ["POR", "URU", "GHA", "QAT"],
  I: ["ENG", "SRB", "ALG", "PAR"],
  J: ["GER", "COL", "NGA", "PER"],
  K: ["NED", "JPN", "TUR", "CHI"],
  L: ["CRO", "POL", "VEN", "JAM"],
};

/* Generate 72 matches across June 11–27 with realistic scheduling.
   Each group plays 6 matches across 3 matchdays.
   Matchday 1: days 1–4, Matchday 2: days 5–8, Matchday 3: days 9–12. */
const CITIES = {
  A: ["Estadio Azteca, CDMX", "Estadio Akron, Guadalajara", "Estadio BBVA, Monterrey"],
  B: ["BMO Field, Toronto", "BC Place, Vancouver", "BMO Field, Toronto"],
  C: ["Mercedes-Benz, Atlanta", "Lincoln Financial, Filadelfia", "NRG Stadium, Houston"],
  D: ["MetLife, Nueva York", "Lincoln Financial, Filadelfia", "Hard Rock, Miami"],
  E: ["SoFi Stadium, Los Ángeles", "Levi's, San Francisco", "Lumen Field, Seattle"],
  F: ["Estadio Azteca, CDMX", "Arrowhead, Kansas City", "Gillette, Boston"],
  G: ["Hard Rock, Miami", "AT&T Stadium, Dallas", "NRG Stadium, Houston"],
  H: ["BC Place, Vancouver", "Lumen Field, Seattle", "BMO Field, Toronto"],
  I: ["MetLife, Nueva York", "Gillette, Boston", "AT&T Stadium, Dallas"],
  J: ["Mercedes-Benz, Atlanta", "Estadio BBVA, Monterrey", "Arrowhead, Kansas City"],
  K: ["SoFi Stadium, Los Ángeles", "Levi's, San Francisco", "Hard Rock, Miami"],
  L: ["Estadio Akron, Guadalajara", "AT&T Stadium, Dallas", "Estadio Azteca, CDMX"],
};

// Generate matches: group, matchday, home, away, kickoff (ISO), city
function generateMatches() {
  const groupLetters = Object.keys(window.GROUPS);
  const matches = [];
  const baseDate = new Date("2026-06-11T12:00:00-06:00");

  // Define matchday pairings within a group of 4 (teams indexed 0..3)
  // Md1: 0v1, 2v3 | Md2: 0v2, 1v3 | Md3: 0v3, 1v2
  const matchdayPairs = [
    [[0,1], [2,3]],
    [[0,2], [1,3]],
    [[0,3], [1,2]],
  ];

  // Schedule: spread matchday 1 across days 1–4, md2 days 5–8, md3 days 9–12
  // 12 groups × 2 matches = 24 matches per matchday. 4 days × 6 slots = 24. Times: 11:00, 13:00, 15:00, 17:00, 19:00, 21:00 local? Use 4 slots.
  // Use 6 slots per day: 10:00, 12:00, 14:00, 16:00, 18:00, 20:00 (CT)
  const slots = ["11:00", "13:00", "15:00", "17:00", "19:00", "21:00"];

  let id = 1;
  for (let md = 0; md < 3; md++) {
    // 24 matches per matchday, scheduled across 4 days × 6 slots
    const matchdayMatches = [];
    groupLetters.forEach((letter, gIdx) => {
      const teams = window.GROUPS[letter];
      matchdayPairs[md].forEach((pair, pIdx) => {
        const home = teams[pair[0]];
        const away = teams[pair[1]];
        matchdayMatches.push({ group: letter, home, away, gIdx, pIdx });
      });
    });
    // Distribute: day 0–3 of matchday, slot 0–5
    matchdayMatches.forEach((m, idx) => {
      const dayOffset = md * 4 + (idx % 4); // 0–11 across whole group stage
      const slotIdx = Math.floor(idx / 4) % slots.length;
      const date = new Date(baseDate);
      date.setDate(date.getDate() + dayOffset);
      const [hh, mm] = slots[slotIdx].split(":");
      date.setHours(parseInt(hh), parseInt(mm), 0, 0);
      const cityArr = CITIES[m.group] || ["TBD"];
      const city = cityArr[md % cityArr.length];
      matches.push({
        id: "M" + String(id).padStart(3, "0"),
        group: m.group,
        matchday: md + 1,
        home: m.home,
        away: m.away,
        kickoff: date.toISOString(),
        city,
      });
      id++;
    });
  }
  // Sort by kickoff
  matches.sort((a, b) => new Date(a.kickoff) - new Date(b.kickoff));
  return matches;
}

window.MATCHES = generateMatches();

/* Demo current user — Carlos Méndez from Mantic Consulting */
window.CURRENT_USER = {
  id: "u-carlos",
  name: "Carlos Méndez",
  email: "carlos.mendez@manticconsulting.com",
  company: "Mantic Consulting",
  department: "Tecnología",
  avatar: { initials: "CM", color: "#006847" },
};

/* Predictions by current user — predicted ~52 of 72 matches.
   Schema: { matchId, winner: "home"|"draw"|"away", score?: {h, a}, withScore: bool } */
function buildCurrentUserPredictions() {
  // Deterministic pseudo-random based on match id index
  const preds = {};
  const matches = window.MATCHES;
  matches.forEach((m, i) => {
    // Skip ~28% of matches to make some look "pending"
    if ((i * 7 + 3) % 9 === 0 || i >= 58) return; // last 14 unpredicted
    // Determine winner heuristically (favor "stronger" team by code position)
    const seedRanks = ["ARG","BRA","FRA","ESP","ENG","GER","POR","NED","ITA","BEL","URU","CRO","COL","MEX","USA","JPN","DEN","SUI","SEN","MAR","POL","SRB","KOR","AUS","CAN","WAL","ECU","NGA","CIV","CMR","CHI","TUN","IRN","ALG","CRC","GHA","TUR","EGY","UKR","SWE","NOR","PAR","PER","VEN","KSA","QAT","NZL","JAM"];
    const hr = seedRanks.indexOf(m.home);
    const ar = seedRanks.indexOf(m.away);
    let winner;
    const diff = ar - hr; // positive = home is stronger
    if ((i % 11) === 0) winner = "draw";
    else if (Math.abs(diff) <= 4 && (i % 13) === 0) winner = "draw";
    else winner = diff > 0 ? "home" : "away";

    // Score: ~30% include explicit score
    const withScore = (i % 3) === 1;
    let score = null;
    if (withScore) {
      if (winner === "home") score = { h: 2, a: 1 };
      else if (winner === "away") score = { h: 0, a: 1 };
      else score = { h: 1, a: 1 };
      // small variation
      if (i % 5 === 0) score = winner === "home" ? { h: 3, a: 1 } : winner === "away" ? { h: 1, a: 2 } : { h: 2, a: 2 };
    }

    preds[m.id] = { matchId: m.id, winner, score, withScore };
  });
  return preds;
}

window.CURRENT_PREDICTIONS = buildCurrentUserPredictions();

/* Leaderboard — 18 employees from Mantic Consulting and GR Plastic.
   Since we're pre-tournament (May 11), points are 0 for everyone.
   Ranking is by predictions completed (a "progress" leaderboard).
   When we switch to "tournament mode", a different points-based leaderboard becomes active. */
window.EMPLOYEES = [
  { id: "u-carlos", name: "Carlos Méndez", company: "Mantic Consulting", dept: "Tecnología", initials: "CM", color: "#006847", completed: 58, exactScores: 24, isMe: true },
  { id: "u-lucia", name: "Lucía Hernández", company: "GR Plastic", dept: "Operaciones", initials: "LH", color: "#ce1126", completed: 72, exactScores: 38 },
  { id: "u-andres", name: "Andrés Vargas", company: "Mantic Consulting", dept: "Consultoría", initials: "AV", color: "#1f3a8a", completed: 72, exactScores: 35 },
  { id: "u-maria", name: "María Robles", company: "GR Plastic", dept: "Calidad", initials: "MR", color: "#d4a017", completed: 70, exactScores: 31 },
  { id: "u-roberto", name: "Roberto Salinas", company: "Mantic Consulting", dept: "Finanzas", initials: "RS", color: "#7c3aed", completed: 68, exactScores: 28 },
  { id: "u-isa", name: "Isabela Cruz", company: "GR Plastic", dept: "Logística", initials: "IC", color: "#0891b2", completed: 64, exactScores: 22 },
  { id: "u-miguel", name: "Miguel Ortega", company: "Mantic Consulting", dept: "Datos", initials: "MO", color: "#ea580c", completed: 60, exactScores: 19 },
  { id: "u-laura", name: "Laura Pineda", company: "GR Plastic", dept: "Recursos Humanos", initials: "LP", color: "#16a34a", completed: 59, exactScores: 20 },
  { id: "u-diego", name: "Diego Mejía", company: "Mantic Consulting", dept: "Tecnología", initials: "DM", color: "#be185d", completed: 55, exactScores: 18 },
  { id: "u-fer", name: "Fernanda Solís", company: "GR Plastic", dept: "Producción", initials: "FS", color: "#0f766e", completed: 52, exactScores: 17 },
  { id: "u-pablo", name: "Pablo Quintero", company: "Mantic Consulting", dept: "Estrategia", initials: "PQ", color: "#9333ea", completed: 50, exactScores: 16 },
  { id: "u-vale", name: "Valeria Núñez", company: "GR Plastic", dept: "Ventas", initials: "VN", color: "#dc2626", completed: 48, exactScores: 14 },
  { id: "u-tomas", name: "Tomás Aguilar", company: "Mantic Consulting", dept: "Tecnología", initials: "TA", color: "#0369a1", completed: 45, exactScores: 13 },
  { id: "u-rosa", name: "Rosa Velázquez", company: "GR Plastic", dept: "Calidad", initials: "RV", color: "#a16207", completed: 42, exactScores: 11 },
  { id: "u-jose", name: "José Camacho", company: "Mantic Consulting", dept: "Consultoría", initials: "JC", color: "#15803d", completed: 38, exactScores: 9 },
  { id: "u-paty", name: "Patricia León", company: "GR Plastic", dept: "Operaciones", initials: "PL", color: "#b91c1c", completed: 34, exactScores: 7 },
  { id: "u-jorge", name: "Jorge Reyes", company: "Mantic Consulting", dept: "Datos", initials: "JR", color: "#1e40af", completed: 28, exactScores: 5 },
  { id: "u-mario", name: "Mario Bautista", company: "GR Plastic", dept: "Producción", initials: "MB", color: "#7e22ce", completed: 18, exactScores: 3 },
];

/* Helpers */
window.fmtDate = function(iso, opts = {}) {
  const d = new Date(iso);
  const days = ["Dom","Lun","Mar","Mié","Jue","Vie","Sáb"];
  const months = ["ene","feb","mar","abr","may","jun","jul","ago","sep","oct","nov","dic"];
  const day = days[d.getDay()];
  const date = d.getDate();
  const month = months[d.getMonth()];
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  if (opts.short) return `${day} ${date} ${month}`;
  if (opts.time) return `${hh}:${mm}`;
  return `${day} ${date} ${month} · ${hh}:${mm}`;
};

window.matchWinner = function(m) {
  if (m.result == null) return null;
  if (m.result.h > m.result.a) return "home";
  if (m.result.h < m.result.a) return "away";
  return "draw";
};

window.flagUrl = function(iso) {
  // Using lipis/flag-icons via jsDelivr — 4x3 SVG
  return `https://cdn.jsdelivr.net/gh/lipis/flag-icons@7.5.0/flags/4x3/${iso}.svg`;
};
