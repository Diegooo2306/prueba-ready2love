/* Quiniela 2026 — Screens */

function LoginScreen({ onLogin }) {
  const [email, setEmail] = React.useState("carlos.mendez@manticconsulting.com");
  const [password, setPassword] = React.useState("••••••••");
  const [loading, setLoading] = React.useState(false);

  function submit(e) {
    e.preventDefault();
    setLoading(true);
    setTimeout(onLogin, 500);
  }

  return (
    <div className="login">
      <div className="login-hero">
        <div className="login-hero-bg"></div>
        <Logo />
        <div>
          <div className="eyebrow" style={{ color: "#c9bda1", marginBottom: 16 }}>Quiniela Corporativa · Edición 2026</div>
          <h1>El mundial<br/>se juega en la <em>oficina</em>.</h1>
          <p style={{ marginTop: 16, fontSize: 16, color: "#d6cdb6", maxWidth: 460 }}>
            72 partidos. 48 selecciones. 1 ganador por equipo, 3 puntos extra si aciertas el marcador. ¿Tienes lo necesario para coronarte campeón de la quiniela Mantic × GR Plastic?
          </p>
        </div>
        <div style={{ display: "flex", gap: 16, color: "#c9bda1", fontSize: 12 }}>
          <span>🇲🇽 México</span>
          <span>🇺🇸 Estados Unidos</span>
          <span>🇨🇦 Canadá</span>
          <span style={{ marginLeft: "auto" }}>11 jun — 19 jul, 2026</span>
        </div>
      </div>
      <div className="login-form-side">
        <div className="login-form">
          <div className="eyebrow">Acceso empleados</div>
          <h2 style={{ marginTop: 8, fontSize: 32 }}>Inicia sesión</h2>
          <p className="text-muted text-sm mt-8">Usa tu cuenta corporativa para participar en la quiniela.</p>

          <div style={{ display: "grid", gap: 10, marginTop: 24 }}>
            <button className="sso-btn" onClick={onLogin}>
              <svg width="18" height="18" viewBox="0 0 23 23"><path fill="#f25022" d="M1 1h10v10H1z"/><path fill="#7fba00" d="M12 1h10v10H12z"/><path fill="#00a4ef" d="M1 12h10v10H1z"/><path fill="#ffb900" d="M12 12h10v10H12z"/></svg>
              Continuar con Microsoft
            </button>
            <button className="sso-btn" onClick={onLogin}>
              <svg width="18" height="18" viewBox="0 0 48 48"><path fill="#FFC107" d="M43.6 20.1H42V20H24v8h11.3c-1.6 4.7-6.1 8-11.3 8-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.6-.4-3.9z"/><path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 16 19 13 24 13c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.3 35.1 26.8 36 24 36c-5.2 0-9.6-3.3-11.3-8l-6.5 5C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.1H42V20H24v8h11.3c-.8 2.3-2.3 4.3-4.1 5.6l6.2 5.2C40.8 35.7 44 30.3 44 24c0-1.3-.1-2.6-.4-3.9z"/></svg>
              Continuar con Google
            </button>
          </div>

          <div className="divider">o con tu correo</div>

          <form onSubmit={submit} style={{ display: "grid", gap: 14 }}>
            <div className="field">
              <label>Correo corporativo</label>
              <input className="input" value={email} onChange={e => setEmail(e.target.value)} type="email" />
            </div>
            <div className="field">
              <label>Contraseña</label>
              <input className="input" value={password} onChange={e => setPassword(e.target.value)} type="password" />
            </div>
            <button type="submit" className="btn btn-primary btn-block btn-lg" disabled={loading}>
              {loading ? "Ingresando..." : "Entrar a la quiniela"}
            </button>
          </form>
          <p className="text-muted text-xs mt-16" style={{ textAlign: "center" }}>
            Al ingresar aceptas el reglamento interno de la quiniela. Sólo personal activo de Mantic Consulting y GR Plastic.
          </p>
        </div>
      </div>
    </div>
  );
}

/* Dashboard */
function Dashboard({ onNav, onPickMatch }) {
  const matches = window.MATCHES;
  const preds = window.CURRENT_PREDICTIONS;
  const completed = Object.keys(preds).length;
  const total = matches.length;
  const withScoreCount = Object.values(preds).filter(p => p.withScore).length;
  const nextMatch = matches[0]; // first one chronologically

  // Top 5 leaderboard preview
  const lb = [...window.EMPLOYEES].sort((a, b) => b.completed - a.completed).slice(0, 5);
  const myRank = [...window.EMPLOYEES].sort((a, b) => b.completed - a.completed).findIndex(e => e.isMe) + 1;
  const home = window.TEAMS[nextMatch.home];
  const away = window.TEAMS[nextMatch.away];

  return (
    <div>
      <div className="hero">
        <div className="shell">
          <div className="hero-grid">
            <div className="hero-left">
              <div className="eyebrow">Hola, Carlos · Lunes 11 de mayo, 2026</div>
              <h1>Faltan <span style={{ color: "var(--green)" }}>28 días</span> para que cierre tu quiniela.</h1>
              <p className="lead">
                Las predicciones de la fase de grupos se bloquean automáticamente el <b>8 de junio</b>, tres días antes del partido inaugural. Asegura todos tus pronósticos antes.
              </p>
              <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 6 }}>
                <button className="btn btn-primary" onClick={() => onNav("matches")}>Completar pronósticos pendientes</button>
                <button className="btn btn-ghost" onClick={() => onNav("leaderboard")}>Ver ranking completo</button>
              </div>
            </div>
            <div className="countdown-card">
              <div className="label">Próximo partido · Inauguración</div>
              <div className="next-match">
                <Flag iso={home.iso} size="lg" />
                <div className="team">{home.code}<small>{home.name}</small></div>
                <div className="vs">vs</div>
                <div className="team">{away.code}<small>{away.name}</small></div>
                <Flag iso={away.iso} size="lg" />
              </div>
              <CountdownBlocks targetIso={nextMatch.kickoff} />
              <div style={{ marginTop: 14, fontSize: 12, color: "#c9bda1", display: "flex", justifyContent: "space-between", gap: 12 }}>
                <span>📍 {nextMatch.city}</span>
                <span>{window.fmtDate(nextMatch.kickoff)} h</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="section">
        <div className="shell">
          <div className="stat-grid">
            <div className="stat">
              <div className="lab">Mi progreso</div>
              <div className="val">{completed}<small>/ {total}</small></div>
              <div style={{ marginTop: 10 }}><Progress value={completed} max={total} /></div>
              <div className="delta">{Math.round(completed/total*100)}% completado</div>
            </div>
            <div className="stat">
              <div className="lab">Marcadores exactos</div>
              <div className="val">{withScoreCount}</div>
              <div className="delta">+3 pts c/u si aciertas</div>
            </div>
            <div className="stat">
              <div className="lab">Mi posición</div>
              <div className="val">#{myRank}<small> / {window.EMPLOYEES.length}</small></div>
              <div className="delta">Por predicciones enviadas</div>
            </div>
            <div className="stat">
              <div className="lab">Bote del ganador</div>
              <div className="val">$12,400<small> MXN</small></div>
              <div className="delta">Aporta cada participante</div>
            </div>
          </div>

          <div className="banner warn mt-24">
            <div className="banner-icon">!</div>
            <div style={{ flex: 1 }}>
              <b>Te faltan {total - completed} pronósticos por enviar.</b> Después del 8 de junio no podrás modificarlos.
            </div>
            <button className="btn btn-sm" style={{ background: "rgba(255,255,255,0.18)", color: "#fff" }} onClick={() => onNav("matches")}>Completar →</button>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 24, marginTop: 32 }} className="dash-grid">
            <div>
              <div className="section-head" style={{ marginBottom: 14 }}>
                <div>
                  <h2>Próximos partidos</h2>
                  <div className="desc">Los primeros encuentros del torneo.</div>
                </div>
                <button className="btn btn-sm btn-ghost" onClick={() => onNav("matches")}>Ver todos</button>
              </div>
              <div className="card">
                <div className="group-matches" style={{ padding: 8 }}>
                  {matches.slice(0, 6).map(m => (
                    <MatchRow key={m.id} match={m} prediction={preds[m.id]} onClick={() => onPickMatch(m)} />
                  ))}
                </div>
              </div>
            </div>
            <div>
              <div className="section-head" style={{ marginBottom: 14 }}>
                <div>
                  <h2>Ranking</h2>
                  <div className="desc">Top empleados por avance.</div>
                </div>
                <button className="btn btn-sm btn-ghost" onClick={() => onNav("leaderboard")}>Ver más</button>
              </div>
              <div className="leaderboard">
                <div className="lb-row head">
                  <div>#</div><div>Empleado</div><div className="hide-mob">Marc.</div><div className="hide-mob">Avance</div><div style={{textAlign:"right"}}>Pts</div>
                </div>
                {lb.map((u, i) => (
                  <div key={u.id} className={`lb-row ${i === 0 ? "top1" : i === 1 ? "top2" : i === 2 ? "top3" : ""} ${u.isMe ? "me" : ""}`}>
                    <div className="lb-rank">{i + 1}</div>
                    <div className="lb-name">
                      <Avatar initials={u.initials} color={u.color} size={32} />
                      <div className="meta"><b>{u.name}{u.isMe && " (tú)"}</b><small>{u.company}</small></div>
                    </div>
                    <div className="lb-stat hide-mob">{u.exactScores}</div>
                    <div className="lb-stat hide-mob">{u.completed}/72</div>
                    <div className="lb-pts">0</div>
                  </div>
                ))}
              </div>
              <div className="text-muted text-xs" style={{ marginTop: 10, textAlign: "center" }}>
                Los puntos se activan al iniciar el torneo · 11 de junio
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* Matches by Group */
function MatchesScreen({ onPickMatch }) {
  const [filter, setFilter] = React.useState("all"); // all, pending, predicted
  const preds = window.CURRENT_PREDICTIONS;
  const matches = window.MATCHES;
  const groups = window.GROUPS;

  const visibleMatches = matches.filter(m => {
    if (filter === "pending") return !preds[m.id];
    if (filter === "predicted") return !!preds[m.id];
    return true;
  });

  const pendingCount = matches.filter(m => !preds[m.id]).length;

  return (
    <div className="section">
      <div className="shell">
        <div className="section-head">
          <div>
            <div className="eyebrow">Fase de grupos · 72 partidos</div>
            <h1 style={{ marginTop: 6 }}>Tus pronósticos</h1>
            <div className="desc">Elige al ganador de cada partido. Activa el marcador exacto para sumar +3 pts adicionales.</div>
          </div>
          <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
            <div className="chip gold">⏰ Cierre: 8 jun, 21:00</div>
            <div className="chip green">{Object.keys(preds).length}/72 enviados</div>
          </div>
        </div>

        <div className="filter-bar">
          <button className={`tab-pill ${filter === "all" ? "active" : ""}`} onClick={() => setFilter("all")}>
            Todos · {matches.length}
          </button>
          <button className={`tab-pill ${filter === "pending" ? "active" : ""}`} onClick={() => setFilter("pending")}>
            Pendientes · {pendingCount}
          </button>
          <button className={`tab-pill ${filter === "predicted" ? "active" : ""}`} onClick={() => setFilter("predicted")}>
            Pronosticados · {Object.keys(preds).length}
          </button>
        </div>

        <div className="group-grid">
          {Object.keys(groups).map(letter => {
            const groupMatches = visibleMatches.filter(m => m.group === letter);
            if (groupMatches.length === 0) return null;
            const groupTeams = groups[letter];
            const allGroupMatches = matches.filter(m => m.group === letter);
            const groupPredicted = allGroupMatches.filter(m => preds[m.id]).length;
            return (
              <div className="group-card" key={letter}>
                <div className="group-head">
                  <div className="group-letter">{letter}</div>
                  <div className="group-head-text">
                    <h3>Grupo {letter}</h3>
                    <div className="sub">{groupPredicted}/{allGroupMatches.length} pronósticos enviados</div>
                  </div>
                  <Progress value={groupPredicted} max={allGroupMatches.length} />
                </div>
                <div className="group-teams">
                  {groupTeams.map(code => {
                    const t = window.TEAMS[code];
                    return (
                      <div className="group-team" key={code}>
                        <Flag iso={t.iso} size="sm" />
                        <span className="name">{t.name}</span>
                        <span className="pts">{t.code}</span>
                      </div>
                    );
                  })}
                </div>
                <div className="group-matches">
                  {groupMatches.map(m => (
                    <MatchRow key={m.id} match={m} prediction={preds[m.id]} onClick={() => onPickMatch(m)} />
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

/* History */
function HistoryScreen({ onPickMatch }) {
  const preds = window.CURRENT_PREDICTIONS;
  const matches = window.MATCHES;
  const predicted = matches.filter(m => preds[m.id]);

  // Group by matchday
  const byMatchday = {};
  predicted.forEach(m => {
    const k = `Jornada ${m.matchday}`;
    if (!byMatchday[k]) byMatchday[k] = [];
    byMatchday[k].push(m);
  });

  return (
    <div className="section">
      <div className="shell">
        <div className="section-head">
          <div>
            <div className="eyebrow">Mi historial</div>
            <h1 style={{ marginTop: 6 }}>Predicciones enviadas</h1>
            <div className="desc">Todos los pronósticos que has registrado. Cuando inicie el torneo, aquí verás qué acertaste y qué fallaste.</div>
          </div>
        </div>

        <div className="stat-grid" style={{ marginBottom: 24 }}>
          <div className="stat">
            <div className="lab">Total enviadas</div>
            <div className="val">{predicted.length}<small>/ 72</small></div>
          </div>
          <div className="stat">
            <div className="lab">Con marcador exacto</div>
            <div className="val">{predicted.filter(m => preds[m.id].withScore).length}</div>
          </div>
          <div className="stat">
            <div className="lab">Picks por ganador local</div>
            <div className="val">{predicted.filter(m => preds[m.id].winner === "home").length}</div>
          </div>
          <div className="stat">
            <div className="lab">Empates pronosticados</div>
            <div className="val">{predicted.filter(m => preds[m.id].winner === "draw").length}</div>
          </div>
        </div>

        {Object.entries(byMatchday).map(([title, ms]) => (
          <div key={title} style={{ marginBottom: 28 }}>
            <h3 style={{ marginBottom: 10 }}>{title} <span className="text-muted text-sm" style={{ fontWeight: 500, fontFamily: "var(--sans)" }}>· {ms.length} partidos</span></h3>
            <div className="card">
              <div className="group-matches" style={{ padding: 8 }}>
                {ms.map(m => (
                  <MatchRow key={m.id} match={m} prediction={preds[m.id]} onClick={() => onPickMatch(m)} />
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* Leaderboard */
function LeaderboardScreen() {
  const [scope, setScope] = React.useState("global"); // global, mantic, gr
  const employees = window.EMPLOYEES;
  const filtered = employees.filter(u => {
    if (scope === "mantic") return u.company === "Mantic Consulting";
    if (scope === "gr") return u.company === "GR Plastic";
    return true;
  }).sort((a, b) => b.completed - a.completed);

  return (
    <div className="section">
      <div className="shell">
        <div className="section-head">
          <div>
            <div className="eyebrow">Ranking</div>
            <h1 style={{ marginTop: 6 }}>Tabla general</h1>
            <div className="desc">Ranking por pronósticos enviados. Los puntos se activan al iniciar el torneo el 11 de junio.</div>
          </div>
          <div className="chip dark">{window.EMPLOYEES.length} participantes</div>
        </div>

        <div className="filter-bar">
          <button className={`tab-pill ${scope === "global" ? "active" : ""}`} onClick={() => setScope("global")}>
            🌎 Global · {employees.length}
          </button>
          <button className={`tab-pill ${scope === "mantic" ? "active" : ""}`} onClick={() => setScope("mantic")}>
            Mantic Consulting · {employees.filter(u => u.company === "Mantic Consulting").length}
          </button>
          <button className={`tab-pill ${scope === "gr" ? "active" : ""}`} onClick={() => setScope("gr")}>
            GR Plastic · {employees.filter(u => u.company === "GR Plastic").length}
          </button>
        </div>

        <div className="leaderboard">
          <div className="lb-row head">
            <div>#</div>
            <div>Empleado</div>
            <div className="hide-mob">Marc. exactos</div>
            <div className="hide-mob">Avance</div>
            <div style={{textAlign: "right"}}>Pts</div>
          </div>
          {filtered.map((u, i) => (
            <div key={u.id} className={`lb-row ${i === 0 ? "top1" : i === 1 ? "top2" : i === 2 ? "top3" : ""} ${u.isMe ? "me" : ""}`}>
              <div className="lb-rank">{i + 1}</div>
              <div className="lb-name">
                <Avatar initials={u.initials} color={u.color} size={36} />
                <div className="meta"><b>{u.name}{u.isMe ? " (tú)" : ""}</b><small>{u.company} · {u.dept}</small></div>
              </div>
              <div className="lb-stat hide-mob">{u.exactScores}</div>
              <div className="lb-stat hide-mob">{u.completed}/72 ({Math.round(u.completed/72*100)}%)</div>
              <div className="lb-pts">0</div>
            </div>
          ))}
        </div>

        <div className="banner info mt-24">
          <div className="banner-icon">i</div>
          <div>
            <b>El ranking por puntos se activa el 11 de junio.</b> Hasta entonces, la tabla ordena por número de pronósticos enviados — completar tu quiniela a tiempo es la primera carrera del torneo.
          </div>
        </div>
      </div>
    </div>
  );
}

/* Profile */
function ProfileScreen() {
  const u = window.CURRENT_USER;
  const preds = window.CURRENT_PREDICTIONS;
  const completed = Object.keys(preds).length;
  const withScore = Object.values(preds).filter(p => p.withScore).length;
  const homePicks = Object.values(preds).filter(p => p.winner === "home").length;
  const drawPicks = Object.values(preds).filter(p => p.winner === "draw").length;
  const awayPicks = Object.values(preds).filter(p => p.winner === "away").length;

  return (
    <div className="section">
      <div className="shell">
        <div className="section-head">
          <div>
            <div className="eyebrow">Perfil</div>
            <h1 style={{ marginTop: 6 }}>Mi cuenta</h1>
          </div>
        </div>

        <div className="card padded" style={{ display: "flex", gap: 20, alignItems: "center" }}>
          <Avatar initials={u.avatar.initials} color={u.avatar.color} size={72} />
          <div style={{ flex: 1 }}>
            <h2>{u.name}</h2>
            <div className="text-muted text-sm">{u.email}</div>
            <div style={{ display: "flex", gap: 8, marginTop: 10, flexWrap: "wrap" }}>
              <span className="chip green">{u.company}</span>
              <span className="chip">{u.department}</span>
              <span className="chip blue">Empleado activo</span>
            </div>
          </div>
          <button className="btn btn-ghost">Editar perfil</button>
        </div>

        <h3 style={{ marginTop: 32, marginBottom: 14 }}>Estadísticas de tu quiniela</h3>
        <div className="stat-grid">
          <div className="stat">
            <div className="lab">Pronósticos enviados</div>
            <div className="val">{completed}<small>/72</small></div>
            <div className="delta">{Math.round(completed/72*100)}% completado</div>
          </div>
          <div className="stat">
            <div className="lab">% de aciertos</div>
            <div className="val">—</div>
            <div className="delta" style={{ color: "var(--muted)" }}>Inicia con el torneo</div>
          </div>
          <div className="stat">
            <div className="lab">Marcadores exactos apostados</div>
            <div className="val">{withScore}</div>
            <div className="delta">Potencial: +{withScore * 3} pts bonus</div>
          </div>
          <div className="stat">
            <div className="lab">Posición actual</div>
            <div className="val">#1<small> / 18</small></div>
            <div className="delta">Por avance</div>
          </div>
        </div>

        <h3 style={{ marginTop: 32, marginBottom: 14 }}>Distribución de tus picks</h3>
        <div className="card padded">
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16 }}>
            <div>
              <div className="eyebrow">Local gana</div>
              <div style={{ fontFamily: "var(--display)", fontSize: 40, fontWeight: 800, marginTop: 4, color: "var(--green-2)" }}>{homePicks}</div>
              <div className="progress" style={{ marginTop: 6 }}><span style={{ width: `${homePicks/completed*100}%`, background: "var(--green)" }}></span></div>
            </div>
            <div>
              <div className="eyebrow">Empate</div>
              <div style={{ fontFamily: "var(--display)", fontSize: 40, fontWeight: 800, marginTop: 4, color: "var(--gold)" }}>{drawPicks}</div>
              <div className="progress" style={{ marginTop: 6 }}><span style={{ width: `${drawPicks/completed*100}%`, background: "var(--gold)" }}></span></div>
            </div>
            <div>
              <div className="eyebrow">Visitante gana</div>
              <div style={{ fontFamily: "var(--display)", fontSize: 40, fontWeight: 800, marginTop: 4, color: "var(--red-2)" }}>{awayPicks}</div>
              <div className="progress" style={{ marginTop: 6 }}><span style={{ width: `${awayPicks/completed*100}%`, background: "var(--red)" }}></span></div>
            </div>
          </div>
        </div>

        <h3 style={{ marginTop: 32, marginBottom: 14 }}>Reglas de la quiniela</h3>
        <div className="card padded">
          <ul style={{ margin: 0, paddingLeft: 18, lineHeight: 1.8, fontSize: 14 }}>
            <li><b>+1 punto</b> por acertar al ganador del partido (Equipo A / Empate / Equipo B).</li>
            <li><b>+3 puntos adicionales</b> si activaste "marcador exacto" y aciertas el resultado.</li>
            <li>Los pronósticos de la fase de grupos se <b>bloquean el 8 de junio a las 21:00</b> — 3 días antes del partido inaugural.</li>
            <li>Sólo cuenta para empleados activos de Mantic Consulting y GR Plastic.</li>
            <li>El ganador se lleva el bote acumulado al cierre de la fase de grupos.</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  LoginScreen, Dashboard, MatchesScreen, HistoryScreen, LeaderboardScreen, ProfileScreen,
});
